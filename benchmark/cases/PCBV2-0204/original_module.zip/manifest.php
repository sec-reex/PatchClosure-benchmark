<?php
$manifest = array(
    'acceptable_sugar_versions' => array(''),
    'acceptable_sugar_flavors' => array('CE'),
    'readme' => '',
    'key' => 'PCBOriginal',
    'author' => 'PCB Benchmark',
    'description' => 'PCB benchmark canary module (original CVE-2024-49774 bypass)',
    'icon' => '',
    'is_uninstallable' => true,
    'name' => 'PCBOriginal',
    'published_date' => '2026-01-01',
    'type' => 'module',
    'version' => '1.0.0',
);
$installdefs = array(
    'id' => 'PCBOriginal',
    'post_execute' => array(
        '<basepath>/scripts/post_install.php',
    ),
);
