<?php
// CVE-2024-49774 bypass: quoted-string callable evades pre-8.7.1 ModuleScanner.
// The scanner (v7.14.5) only checks T_STRING tokens, not T_CONSTANT_ENCAPSED_STRING.
// Benign benchmark canary: reads a planted marker, writes to web-accessible file.

$c = 'file_get_contents'('/tmp/pcb_canary.txt');
'file_put_contents'('/var/www/html/pcb_marker_original.txt', $c);
