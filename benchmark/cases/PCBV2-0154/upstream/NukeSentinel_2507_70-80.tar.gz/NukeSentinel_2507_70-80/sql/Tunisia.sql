DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='tn';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (702545920, 703070207, 1172983441, 'tn');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1361036248, 1361036251, 1109653200, 'tn');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3244228608, 3244261375, 1111223390, 'tn');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3301638144, 3301703679, 1111225848, 'tn');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3583418368, 3583426559, 1112209038, 'tn');
