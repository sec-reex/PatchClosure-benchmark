<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

$pagetitle = $pagename;
include("header.php");
title("$pagetitle");
OpenTable();
echo "<table align='center' border='0' cellpadding='2' cellspacing='2'>\n";
echo "<form action='".$_SERVER['PHP_SELF']."' method='post'>\n";
echo "<tr><td>This script will install, remove, or upgrade the tables for the $pagetitle.</td></tr>\n";
echo "<tr><td><strong>Backup data tables before going on!</strong></td></tr>\n";
echo "<tr><td><select name='op'>\n";
if(file_exists("nsnst_installer/install.php")) {
  echo "<option value=''>---- Install Options ----</option>\n";
  echo "<option value='install'>$pagename First Time Install</option>\n";
}
echo "<option value=''>---- Upgrade Options ----</option>\n";
if(file_exists("nsnst_installer/up2506-2507.php")) { echo "<option value='up2506-2507'>Upgrade $pagename 2.5.06 to 2.5.07 tables</option>\n"; }
if(file_exists("nsnst_installer/up2505-2506.php")) { echo "<option value='up2505-2506'>Upgrade $pagename 2.5.05 to 2.5.06 tables</option>\n"; }
if(file_exists("nsnst_installer/up2504-2505.php")) { echo "<option value='up2504-2505'>Upgrade $pagename 2.5.04 to 2.5.05 tables</option>\n"; }
if(file_exists("nsnst_installer/up2503-2504.php")) { echo "<option value='up2503-2504'>Upgrade $pagename 2.5.03 to 2.5.04 tables</option>\n"; }
if(file_exists("nsnst_installer/up2502-2503.php")) { echo "<option value='up2502-2503'>Upgrade $pagename 2.5.02 to 2.5.03 tables</option>\n"; }
if(file_exists("nsnst_installer/up2501-2502.php")) { echo "<option value='up2501-2502'>Upgrade $pagename 2.5.01 to 2.5.02 tables</option>\n"; }
if(file_exists("nsnst_installer/up2500-2501.php")) { echo "<option value='up2500-2501'>Upgrade $pagename 2.5.00 to 2.5.01 tables</option>\n"; }
if(file_exists("nsnst_installer/up242x-2500.php")) { echo "<option value='up242x-2500'>Upgrade $pagename 2.4.2x to 2.5.00 tables</option>\n"; }

if(file_exists("nsnst_installer/up242pl8-242pl9.php")) { echo "<option value='up242pl8-242pl9'>Upgrade $pagename 2.4.2pl8 to 2.4.2pl9 tables</option>\n"; }
if(file_exists("nsnst_installer/up242pl7-242pl8.php")) { echo "<option value='up242pl7-242pl8'>Upgrade $pagename 2.4.2pl7 to 2.4.2pl8 tables</option>\n"; }
if(file_exists("nsnst_installer/up242pl6-242pl7.php")) { echo "<option value='up242pl6-242pl7'>Upgrade $pagename 2.4.2pl6 to 2.4.2pl7 tables</option>\n"; }
if(file_exists("nsnst_installer/up242pl5-242pl6.php")) { echo "<option value='up242pl5-242pl6'>Upgrade $pagename 2.4.2pl5 to 2.4.2pl6 tables</option>\n"; }
if(file_exists("nsnst_installer/up242pl4-242pl5.php")) { echo "<option value='up242pl4-242pl5'>Upgrade $pagename 2.4.2pl4 to 2.4.2pl5 tables</option>\n"; }
if(file_exists("nsnst_installer/up242pl3-242pl4.php")) { echo "<option value='up242pl3-242pl4'>Upgrade $pagename 2.4.2pl3 to 2.4.2pl4 tables</option>\n"; }
if(file_exists("nsnst_installer/up242pl2-242pl3.php")) { echo "<option value='up242pl2-242pl3'>Upgrade $pagename 2.4.2pl2 to 2.4.2pl3 tables</option>\n"; }
if(file_exists("nsnst_installer/up242pl1-242pl2.php")) { echo "<option value='up242pl1-242pl2'>Upgrade $pagename 2.4.2pl1 to 2.4.2pl2 tables</option>\n"; }
if(file_exists("nsnst_installer/up242-242pl1.php")) { echo "<option value='up242-242pl1'>Upgrade $pagename 2.4.2 to 2.4.2pl1 tables</option>\n"; }
if(file_exists("nsnst_installer/up241-242.php")) { echo "<option value='up241-242'>Upgrade $pagename 2.4.1 to 2.4.2 tables</option>\n"; }
if(file_exists("nsnst_installer/up240b-241.php")) { echo "<option value='up240b-241'>Upgrade $pagename 2.4.0b to 2.4.1 tables</option>\n"; }
if(file_exists("nsnst_installer/up240a-240b.php")) { echo "<option value='up240a-240b'>Upgrade $pagename 2.4.0a to 2.4.0b tables</option>\n"; }
if(file_exists("nsnst_installer/up240-240a.php")) { echo "<option value='up240-240a'>Upgrade $pagename 2.4.0 to 2.4.0a tables</option>\n"; }
if(file_exists("nsnst_installer/up232-240.php")) { echo "<option value='up232-240'>Upgrade $pagename 2.3.2 to 2.4.0 tables</option>\n"; }
if(file_exists("nsnst_installer/up231-232.php")) { echo "<option value='up231-232'>Upgrade $pagename 2.3.1 to 2.3.2 tables</option>\n"; }
if(file_exists("nsnst_installer/up230-231.php")) { echo "<option value='up230-231'>Upgrade $pagename 2.3.0 to 2.3.1 tables</option>\n"; }
if(file_exists("nsnst_installer/up221-230.php")) { echo "<option value='up221-230'>Upgrade $pagename 2.2.1 to 2.3.0 tables</option>\n"; }
if(file_exists("nsnst_installer/up220pl4-221.php")) { echo "<option value='up220pl4-221'>Upgrade $pagename 2.2.0pl4 to 2.2.1 tables</option>\n"; }
if(file_exists("nsnst_installer/up220pl3-220pl4.php")) { echo "<option value='up220pl3-220pl4'>Upgrade $pagename 2.2.0pl3 to 2.2.0pl4 tables</option>\n"; }
if(file_exists("nsnst_installer/up220pl2-220pl3.php")) { echo "<option value='up220pl2-220pl3'>Upgrade $pagename 2.2.0pl2 to 2.2.0pl3 tables</option>\n"; }
if(file_exists("nsnst_installer/up220pl1-220pl2.php")) { echo "<option value='up220pl1-220pl2'>Upgrade $pagename 2.2.0pl1 to 2.2.0pl2 tables</option>\n"; }
if(file_exists("nsnst_installer/up220-220pl1.php")) { echo "<option value='up220-220pl1'>Upgrade $pagename 2.2.0 to 2.2.0pl1 tables</option>\n"; }
if(file_exists("nsnst_installer/up213-220.php")) { echo "<option value='up213-220'>Upgrade $pagename 2.1.3 to 2.2.0 tables</option>\n"; }
if(file_exists("nsnst_installer/up212-213.php")) { echo "<option value='up212-213'>Upgrade $pagename 2.1.2 to 2.1.3 tables</option>\n"; }
if(file_exists("nsnst_installer/up211-212.php")) { echo "<option value='up211-212'>Upgrade $pagename 2.1.1 to 2.1.2 tables</option>\n"; }
if(file_exists("nsnst_installer/up210-211.php")) { echo "<option value='up210-211'>Upgrade $pagename 2.1.0 to 2.1.1 tables</option>\n"; }
if(file_exists("nsnst_installer/up202-210.php")) { echo "<option value='up202-210'>Upgrade $pagename 2.0.2 to 2.1.0 tables</option>\n"; }
if(file_exists("nsnst_installer/up201-202.php")) { echo "<option value='up201-202'>Upgrade $pagename 2.0.1 to 2.0.2 tables</option>\n"; }
if(file_exists("nsnst_installer/up200-201.php")) { echo "<option value='up200-201'>Upgrade $pagename 2.0.0 to 2.0.1 tables</option>\n"; }
if(file_exists("nsnst_installer/up110-120.php")) { echo "<option value='up110-120'>Upgrade $pagename 1.1.0 to 1.2.0 tables</option>\n"; }
if(file_exists("nsnst_installer/up100-110.php")) { echo "<option value='up100-110'>Upgrade $pagename 1.0.0 to 1.1.0 tables</option>\n"; }
if(file_exists("nsnst_installer/remove.php")) {
  echo "<option value=''>---- Removal Options ----</option>\n";
  echo "<option value='remove'>Remove $pagename tables</option>\n";
}
echo "</select> <input type='submit' value='COMMIT'></td></tr>\n";
echo "<tr><td><strong>Once you have finished with this script, delete it from your server!</strong></td></tr>\n";
echo "</form>";
echo "</table><br />\n";
echo "<table border='0' cellpadding='0' cellspacing='0' align='center'>\n";
echo "<tr><td width='100%' align='center'><strong>Help Support NukeSentinel�</strong></td></tr>\n";
echo "<tr><td width='100%' align='center'><a href='http://www.nukescripts.net/modules.php?name=Donations'><img src='https://www.paypal.com/en_US/i/btn/x-click-but21.gif' border='0' alt='Make donations with PayPal!' align='center'></a></td></tr>\n";
echo "</table>\n";
CloseTable();
include("footer.php");

?>