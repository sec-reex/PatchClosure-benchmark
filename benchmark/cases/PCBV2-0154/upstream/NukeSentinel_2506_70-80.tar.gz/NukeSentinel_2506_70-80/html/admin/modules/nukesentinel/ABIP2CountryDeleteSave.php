<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

$getIPs = $db->sql_fetchrow($db->sql_query("SELECT * FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`='$ip_lo' AND `ip_hi`='$ip_hi'"));
list($xcountry) = $db->sql_fetchrow($db->sql_query("SELECT `country` FROM `".$prefix."_nsnst_countries` WHERE `c2c`='$xc2c'"));
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`='$ip_lo' AND `ip_hi`='$ip_hi'");
$db->sql_query("OPTIMIZE TABLE `".$prefix."_nsnst_ip2country`");
if($submittonsn == 1) {
  $subject = _AB_XNUKESENTINEL.": "._AB_XDELETEIP2COUNTRY;
  $message  = "--------------------------------------------------\n";
  $message .= _AB_XIPLO.": ".long2ip($ip_lo)." ($ip_lo)\n";
  $message .= _AB_XIPHI.": ".long2ip($ip_hi)." ($ip_hi)\n";
  $message .= _AB_XCOUNTRY.": ".stripslashes($xcountry)." (".$getIPs['c2c'].")\n";
  $message .= "--------------------------------------------------\n";
  $message .= _AB_XSITENAME.": ".stripslashes($sitename)."\n";
  $message .= _AB_XSITEURL.": $nukeurl\n";
  $message .= "--------------------------------------------------\n";
  @mail("ip2c@nukescripts.net", $subject, $message,"From: $adminmail\r\nX-Mailer: "._AB_NUKESENTINEL);
}
Header("Location: ".$admin_file.".php?op=$xop&min=$min&column=$column&direction=$direction&sip=$sip&showcountry=$showcountry");

?>