<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

$pagetitle = $pagename.": ERROR";
include("header.php");
title("$pagetitle");
OpenTable();
echo "<center><strong>Sorry, ONLY super admins may run this script</strong><center>\n";
CloseTable();
include("footer.php");

?>