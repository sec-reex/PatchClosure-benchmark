<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

@set_time_limit(600);
$pagetitle = $pagename.": Upgrade 2.3.0 to 2.3.1";
include("header.php");
title("$pagetitle");
OpenTable();
echo "Operation Status!<br />\n";
echo "<hr />\n";
$message = "Everything seems to have completed successfully :)<br />\n";
// UPDATE TABLE nsnst_config
list($track_max) = $db->sql_fetchrow($db->sql_query("SELECT config_value FROM `".$prefix."_nsnst_config` WHERE `config_name`='track_max'"));
if($track_max > 0) {
  $result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='604800' WHERE `config_name`='track_max'");
  if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
}
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='track_del'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='search_user_perpage'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='search_user_sort_column'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='search_user_sort_direction'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='search_track_perpage'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='search_track_sort_column'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='search_track_sort_direction'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='search_block_perpage'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='search_block_sort_column'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='search_block_sort_direction'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='2.3.1' WHERE `config_name`='version_number'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_config` ORDER BY `config_name`");
if(!$result) { echo "- Adjust Order ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
echo "$message<hr />\n";
echo "Operation Complete!<br />\n";
echo "<strong>NOTE:</strong> If you had IP Tracking active it will now track by number of days.<br />\n";
echo "Click the link below to goto admin:<br />\n";
echo "Goto <a href=\"".$admin_file.".php?op=ABMain\">$pagename Admin</a>\n";
CloseTable();
include("footer.php");

?>