DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='ap';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (2063728640, 2063859711, 1171092890, 'ap');
