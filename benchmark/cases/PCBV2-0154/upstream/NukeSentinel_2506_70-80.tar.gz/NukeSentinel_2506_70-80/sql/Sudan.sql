DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='sd';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (701581312, 701583359, 1171390706, 'sd');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (701593600, 701595647, 1168320042, 'sd');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3252415488, 3252415503, 1109653200, 'sd');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3288449024, 3288465407, 1154831035, 'sd');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3290275840, 3290284031, 1152159366, 'sd');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3301605376, 3301613567, 1112682028, 'sd');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3556802560, 3556810751, 1111552113, 'sd');
