DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='to';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3392864256, 3392864511, 1109653200, 'to');
