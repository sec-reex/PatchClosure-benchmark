DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='tf';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3624292608, 3624292863, 1109653200, 'tf');
