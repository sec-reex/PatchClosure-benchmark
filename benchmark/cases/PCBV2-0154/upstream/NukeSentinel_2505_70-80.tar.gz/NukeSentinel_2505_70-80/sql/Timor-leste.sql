DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='tl';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3393742848, 3393743871, 1109653200, 'tl');
