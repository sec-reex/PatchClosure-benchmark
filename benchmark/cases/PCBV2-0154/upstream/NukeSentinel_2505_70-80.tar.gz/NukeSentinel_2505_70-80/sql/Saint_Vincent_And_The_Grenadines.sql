DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='vc';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3288440832, 3288441103, 1109653200, 'vc');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3288443392, 3288443647, 1109653200, 'vc');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3453406464, 3453406975, 1109653200, 'vc');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3631112192, 3631112703, 1109653200, 'vc');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3631118080, 3631119103, 1109653200, 'vc');
