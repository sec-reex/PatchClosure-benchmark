DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='fo';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1347256320, 1347260415, 1109653200, 'fo');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1347980040, 1347980047, 1109653200, 'fo');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1360191488, 1360195583, 1109653200, 'fo');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1360640000, 1360642047, 1167366348, 'fo');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1481973760, 1481981951, 1151597700, 'fo');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3266767616, 3266767871, 1109653200, 'fo');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3560382464, 3560390655, 1109653200, 'fo');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3651948544, 3651952639, 1109653200, 'fo');
