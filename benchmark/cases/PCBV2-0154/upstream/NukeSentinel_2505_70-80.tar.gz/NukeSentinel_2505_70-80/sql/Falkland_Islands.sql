DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='fk';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3287859456, 3287859711, 1109653200, 'fk');
