DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='er';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3301466112, 3301470207, 1115276203, 'er');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3585835960, 3585835967, 1109653200, 'er');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3586105344, 3586106879, 1109653200, 'er');
