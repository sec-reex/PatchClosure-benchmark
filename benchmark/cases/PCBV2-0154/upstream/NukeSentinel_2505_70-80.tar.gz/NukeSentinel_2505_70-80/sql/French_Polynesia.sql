DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='pf';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3230153472, 3230153727, 1109653200, 'pf');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3268869376, 3268870143, 1109653200, 'pf');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3271426048, 3271426303, 1109653200, 'pf');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3389227008, 3389227263, 1109653200, 'pf');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3389251584, 3389259775, 1109653200, 'pf');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3394912256, 3394920447, 1109653200, 'pf');
