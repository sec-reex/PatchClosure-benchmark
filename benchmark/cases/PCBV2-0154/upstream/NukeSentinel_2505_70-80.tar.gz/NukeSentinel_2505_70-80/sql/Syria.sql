DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='sy';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1359265536, 1359265791, 1109653200, 'sy');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1384759296, 1384775679, 1109653200, 'sy');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1482031104, 1482039295, 1148008362, 'sy');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1536163840, 1536180223, 1163481682, 'sy');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3288466432, 3288467455, 1109653200, 'sy');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3325267712, 3325268735, 1109653200, 'sy');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3558831360, 3558831615, 1109653200, 'sy');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3585269760, 3585277951, 1109653200, 'sy');
