DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='io';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3391909888, 3391910911, 1109653200, 'io');
