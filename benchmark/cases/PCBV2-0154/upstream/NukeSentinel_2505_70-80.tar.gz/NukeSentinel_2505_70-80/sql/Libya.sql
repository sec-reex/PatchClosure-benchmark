DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='ly';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1044652032, 1044660223, 1116363781, 'ly');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1055924224, 1055932415, 1111512908, 'ly');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1357317632, 1357318143, 1114533705, 'ly');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1357370880, 1357371391, 1109653200, 'ly');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3264774912, 3264775167, 1109653200, 'ly');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3653405088, 3653405095, 1109653200, 'ly');
