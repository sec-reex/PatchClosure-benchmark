DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='tk';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3393744128, 3393744143, 1109653200, 'tk');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3393744160, 3393744175, 1109653200, 'tk');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3509534752, 3509534783, 1109653200, 'tk');
