DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='aq';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1438892032, 1438892287, 1109653200, 'aq');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1438900224, 1438908415, 1109653200, 'aq');
