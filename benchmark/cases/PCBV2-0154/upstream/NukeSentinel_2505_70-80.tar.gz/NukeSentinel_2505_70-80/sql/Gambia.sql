DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='gm';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1347979520, 1347979527, 1109653200, 'gm');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3291408384, 3291410431, 1146193594, 'gm');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3560718336, 3560719103, 1130389045, 'gm');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3560719104, 3560726527, 1141804684, 'gm');
