DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='mq';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1362411520, 1362413273, 1109653200, 'mq');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1362426880, 1362427903, 1109653200, 'mq');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3574595584, 3574596095, 1109653200, 'mq');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3574599680, 3574599823, 1109653200, 'mq');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3574600192, 3574600199, 1109653200, 'mq');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3574600208, 3574600215, 1109653200, 'mq');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3574600448, 3574600703, 1109653200, 'mq');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3585908736, 3585911039, 1109653200, 'mq');
