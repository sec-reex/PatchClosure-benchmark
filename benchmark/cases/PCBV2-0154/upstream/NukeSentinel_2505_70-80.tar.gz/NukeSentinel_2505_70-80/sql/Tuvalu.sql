DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='tv';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3389153280, 3389161471, 1109653200, 'tv');
