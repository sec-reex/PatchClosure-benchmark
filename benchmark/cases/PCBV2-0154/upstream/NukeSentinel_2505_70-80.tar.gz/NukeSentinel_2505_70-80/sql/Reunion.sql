DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='re';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3262478432, 3262478432, 1109653200, 're');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3278943538, 3278943538, 1109653200, 're');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3560939912, 3560939915, 1109653200, 're');
