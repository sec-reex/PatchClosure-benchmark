DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='ck';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3393265664, 3393273855, 1109653200, 'ck');
