DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='nc';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3389037568, 3389038591, 1109653200, 'nc');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3390472192, 3390480383, 1109653200, 'nc');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3390496768, 3390500863, 1109653200, 'nc');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3394732032, 3394740223, 1109653200, 'nc');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3400220672, 3400224767, 1109653200, 'nc');
