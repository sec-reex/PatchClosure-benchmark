DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='bt';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3398467584, 3398475775, 1109653200, 'bt');
