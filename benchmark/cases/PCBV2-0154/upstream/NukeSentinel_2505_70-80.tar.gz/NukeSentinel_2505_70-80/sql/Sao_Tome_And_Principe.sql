DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='st';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3272083456, 3272083711, 1109653200, 'st');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3272084480, 3272084735, 1109653200, 'st');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3272089344, 3272089479, 1109653200, 'st');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3272089536, 3272089551, 1109653200, 'st');
