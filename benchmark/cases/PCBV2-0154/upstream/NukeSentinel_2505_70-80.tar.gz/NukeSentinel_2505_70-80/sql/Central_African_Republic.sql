DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='cf';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3252418304, 3252418559, 1109653200, 'cf');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3254487296, 3254487419, 1109653200, 'cf');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3254490368, 3254490623, 1109653200, 'cf');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3268299008, 3268299263, 1109653200, 'cf');
