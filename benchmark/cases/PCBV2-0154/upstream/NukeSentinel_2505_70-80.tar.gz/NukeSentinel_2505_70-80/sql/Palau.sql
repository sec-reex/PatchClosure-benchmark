DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='pw';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3397181440, 3397185535, 1109653200, 'pw');
