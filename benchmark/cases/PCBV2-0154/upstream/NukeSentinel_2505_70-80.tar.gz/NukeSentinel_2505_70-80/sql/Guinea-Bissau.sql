DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='gw';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1347980272, 1347980287, 1109653200, 'gw');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3259062016, 3259062271, 1109653200, 'gw');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3272084992, 3272085503, 1109653200, 'gw');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3633553152, 3633553279, 1109653200, 'gw');
