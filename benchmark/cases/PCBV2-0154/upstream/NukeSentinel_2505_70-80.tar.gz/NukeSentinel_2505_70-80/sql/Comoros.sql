DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='km';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1357366016, 1357366271, 1109653200, 'km');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3254487040, 3254487199, 1109653200, 'km');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3254487264, 3254487295, 1109653200, 'km');
