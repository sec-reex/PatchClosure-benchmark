DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='sm';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1046352832, 1046352847, 1109653200, 'sm');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1357334016, 1357334271, 1109653200, 'sm');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1357335552, 1357335807, 1109653200, 'sm');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3256187392, 3256187647, 1109653200, 'sm');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3266789376, 3266797567, 1109653200, 'sm');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3278943821, 3278943821, 1109653200, 'sm');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3560940624, 3560940627, 1109653200, 'sm');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3583558400, 3583558527, 1109653200, 'sm');
