DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='sc';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3288430592, 3288432639, 1130210138, 'sc');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3393741824, 3393742591, 1109653200, 'sc');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3393744384, 3393744415, 1109653200, 'sc');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3411773440, 3411773695, 1109653200, 'sc');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3411776512, 3411776767, 1109653200, 'sc');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3651236864, 3651237631, 1109653200, 'sc');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3651237888, 3651238399, 1109653200, 'sc');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3651858688, 3651858943, 1109653200, 'sc');
