DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='cv';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3272081920, 3272082431, 1109653200, 'cv');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3272084224, 3272084479, 1109653200, 'cv');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3272084736, 3272084991, 1109653200, 'cv');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3272087808, 3272088063, 1109653200, 'cv');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3272088320, 3272088575, 1109653200, 'cv');
