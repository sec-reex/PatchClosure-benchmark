DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='kh';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (2087464960, 2087467007, 1164256310, 'kh');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3392102400, 3392106495, 1109653200, 'kh');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3415228416, 3415236607, 1109653200, 'kh');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3418193920, 3418202111, 1109653200, 'kh');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3420397568, 3420401663, 1109653200, 'kh');
