DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='as';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1075660544, 1075660799, 1109653200, 'as');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1075662848, 1075663103, 1109653200, 'as');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1075664640, 1075664895, 1109653200, 'as');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3393613824, 3393617919, 1109653200, 'as');
