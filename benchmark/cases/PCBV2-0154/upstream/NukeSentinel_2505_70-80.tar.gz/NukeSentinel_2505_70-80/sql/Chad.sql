DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='td';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1343222528, 1343222579, 1109653200, 'td');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1343222784, 1343222911, 1109653200, 'td');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3252409344, 3252409375, 1109653200, 'td');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3254489856, 3254490111, 1109653200, 'td');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3648080960, 3648080991, 1109653200, 'td');
