DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='fm';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1062497792, 1062498303, 1109653200, 'fm');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3459352832, 3459353087, 1109653200, 'fm');
