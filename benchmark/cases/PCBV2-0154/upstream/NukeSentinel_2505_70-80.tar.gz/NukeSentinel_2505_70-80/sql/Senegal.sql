DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='sn';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1043918080, 1043918335, 1109653200, 'sn');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3288424448, 3288424703, 1147402488, 'sn');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3288424960, 3288425215, 1152644875, 'sn');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3301949440, 3301965823, 1111112700, 'sn');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3523702800, 3523702807, 1109653200, 'sn');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3583655936, 3583664127, 1111222841, 'sn');
