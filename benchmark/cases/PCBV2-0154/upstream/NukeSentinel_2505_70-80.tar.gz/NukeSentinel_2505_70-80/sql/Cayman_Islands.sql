DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='ky';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1065906176, 1065908223, 1109653200, 'ky');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3584509360, 3584509367, 1109653200, 'ky');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3584510720, 3584510975, 1109653200, 'ky');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3633336320, 3633340415, 1133766046, 'ky');
