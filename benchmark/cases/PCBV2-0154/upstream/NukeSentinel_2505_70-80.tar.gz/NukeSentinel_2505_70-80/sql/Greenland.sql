DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='gl';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1481834496, 1481842687, 1145936040, 'gl');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3266437120, 3266445311, 1109653200, 'gl');
