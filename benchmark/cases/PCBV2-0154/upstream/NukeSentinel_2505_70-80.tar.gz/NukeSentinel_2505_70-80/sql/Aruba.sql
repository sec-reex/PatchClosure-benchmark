DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='aw';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3338686464, 3338688511, 1109653200, 'aw');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3338825728, 3338827775, 1109653200, 'aw');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3387228160, 3387244543, 1144369643, 'aw');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3436476416, 3436478463, 1109653200, 'aw');
