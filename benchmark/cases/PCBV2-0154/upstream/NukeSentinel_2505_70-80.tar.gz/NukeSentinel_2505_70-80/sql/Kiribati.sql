DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='ki';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3389421568, 3389422591, 1109653200, 'ki');
