DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='fj';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (2423783424, 2423848959, 1109653200, 'fj');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3393060864, 3393062911, 1109653200, 'fj');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3393091072, 3393093631, 1109653200, 'fj');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3400146944, 3400151039, 1109653200, 'fj');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3523674112, 3523682303, 1109653200, 'fj');
