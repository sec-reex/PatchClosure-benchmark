DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='et';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1389265200, 1389265231, 1109653200, 'et');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3577167872, 3577184255, 1115317704, 'et');
