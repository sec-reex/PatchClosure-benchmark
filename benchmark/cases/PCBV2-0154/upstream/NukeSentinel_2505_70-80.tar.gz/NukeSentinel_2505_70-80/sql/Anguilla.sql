DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='ai';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3423533056, 3423535103, 1157249312, 'ai');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3493998592, 3494000639, 1158822702, 'ai');
