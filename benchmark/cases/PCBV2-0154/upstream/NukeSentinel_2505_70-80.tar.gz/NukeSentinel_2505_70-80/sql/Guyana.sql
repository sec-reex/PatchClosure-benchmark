DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='gy';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3192913920, 3192930303, 1164256439, 'gy');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3356287232, 3356287239, 1109653200, 'gy');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3357446328, 3357446335, 1109653200, 'gy');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3498209792, 3498210815, 1109653200, 'gy');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3499712512, 3499713535, 1109653200, 'gy');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3500794880, 3500795903, 1109653200, 'gy');
