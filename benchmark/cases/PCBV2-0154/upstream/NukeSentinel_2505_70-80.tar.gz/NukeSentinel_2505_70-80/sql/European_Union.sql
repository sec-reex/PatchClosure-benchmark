DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='eu';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1043529728, 1043562495, 1126072393, 'eu');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1043562496, 1043595263, 1124416476, 'eu');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1385566720, 1385566975, 1127538659, 'eu');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3263528960, 3263529983, 1127360540, 'eu');
