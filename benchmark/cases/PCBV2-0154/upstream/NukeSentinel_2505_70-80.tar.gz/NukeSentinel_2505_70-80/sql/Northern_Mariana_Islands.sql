DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='mp';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1160563200, 1160563711, 1109653200, 'mp');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3394781184, 3394789375, 1109653200, 'mp');
