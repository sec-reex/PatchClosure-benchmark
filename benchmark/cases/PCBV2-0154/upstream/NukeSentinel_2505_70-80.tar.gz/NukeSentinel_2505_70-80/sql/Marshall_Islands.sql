DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='mh';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1103474944, 1103475199, 1109653200, 'mh');
