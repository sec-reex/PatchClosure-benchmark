DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='nr';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3393742592, 3393742847, 1109653200, 'nr');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3393744144, 3393744159, 1109653200, 'nr');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3412254720, 3412262911, 1109653200, 'nr');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3633035072, 3633035087, 1109653200, 'nr');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3633035136, 3633035151, 1109653200, 'nr');
