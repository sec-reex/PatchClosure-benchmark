DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='bi';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1358900768, 1358900783, 1109653200, 'bi');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1371998208, 1371999231, 1109653200, 'bi');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1389267968, 1389268096, 1109653200, 'bi');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3252409408, 3252409439, 1109653200, 'bi');
