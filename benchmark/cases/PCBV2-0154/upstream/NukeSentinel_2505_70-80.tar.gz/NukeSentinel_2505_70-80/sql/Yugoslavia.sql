DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='yu';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1440645120, 1440677887, 1114754132, 'yu');
