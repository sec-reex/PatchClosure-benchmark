DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='bw';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1401886720, 1401888767, 1109653200, 'bw');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3252409856, 3252410367, 1109653200, 'bw');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3252469248, 3252472159, 1109653200, 'bw');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3590312960, 3590314639, 1109653200, 'bw');
