DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='dj';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3254488832, 3254489087, 1109653200, 'dj');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3254494976, 3254495087, 1109653200, 'dj');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3254509568, 3254509783, 1109653200, 'dj');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3301556224, 3301560319, 1131428682, 'dj');
