DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='va';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1372610048, 1372610303, 1109653200, 'va');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3240846848, 3240847359, 1109653200, 'va');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3240853504, 3240855039, 1109653200, 'va');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3561816064, 3561824255, 1109653200, 'va');
