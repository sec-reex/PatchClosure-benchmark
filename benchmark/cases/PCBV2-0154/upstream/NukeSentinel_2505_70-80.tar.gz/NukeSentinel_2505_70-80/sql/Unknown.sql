DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='00';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (2130706432, 2147483647, 0, '00');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3232235520, 3232301055, 0, '00');
