DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='sz';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1046318080, 1046318591, 1109653200, 'sz');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1051578368, 1051580479, 1109653200, 'sz');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3568916392, 3568916399, 1109653200, 'sz');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3582572480, 3582572495, 1109653200, 'sz');
