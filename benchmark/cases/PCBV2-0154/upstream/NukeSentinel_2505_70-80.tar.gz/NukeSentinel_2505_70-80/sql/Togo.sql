DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='tg';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1043905024, 1043905279, 1109653200, 'tg');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1043905536, 1043906559, 1109653200, 'tg');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1358446592, 1358450687, 1112757421, 'tg');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1372022784, 1372023807, 1109653200, 'tg');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3585702656, 3585702911, 1109653200, 'tg');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3642070080, 3642070111, 1109653200, 'tg');
