DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='gq';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3254491392, 3254491603, 1109653200, 'gq');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3254491616, 3254491647, 1109653200, 'gq');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3254509312, 3254509567, 1109653200, 'gq');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3254523608, 3254523615, 1109653200, 'gq');
