DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='sb';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3389104128, 3389112319, 1109653200, 'sb');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3393191424, 3393191935, 1109653200, 'sb');
