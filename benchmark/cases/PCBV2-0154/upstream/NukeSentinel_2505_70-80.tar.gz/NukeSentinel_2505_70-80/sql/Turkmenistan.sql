DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='tm';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3259223296, 3259223807, 1109653200, 'tm');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3652116480, 3652120575, 1109653200, 'tm');
