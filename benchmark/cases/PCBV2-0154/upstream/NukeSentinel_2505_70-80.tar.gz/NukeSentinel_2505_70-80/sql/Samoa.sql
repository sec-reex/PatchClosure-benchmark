DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='ws';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3389267968, 3389276159, 1109653200, 'ws');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3412328192, 3412328447, 1109653200, 'ws');
