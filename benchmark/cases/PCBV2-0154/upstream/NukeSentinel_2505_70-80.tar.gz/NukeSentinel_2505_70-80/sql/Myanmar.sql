DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='mm';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3411099648, 3411107839, 1109653200, 'mm');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3411124224, 3411128319, 1109653200, 'mm');
