DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='bf';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3290230784, 3290234879, 1148707620, 'bf');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3560210432, 3560218623, 1112159878, 'bf');
