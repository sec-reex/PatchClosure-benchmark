DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='ad';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1432264704, 1432272895, 1109653200, 'ad');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3262479282, 3262479282, 1109653200, 'ad');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3265150976, 3265159167, 1109653200, 'ad');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3278943684, 3278943684, 1109653200, 'ad');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3278943735, 3278943735, 1109653200, 'ad');
