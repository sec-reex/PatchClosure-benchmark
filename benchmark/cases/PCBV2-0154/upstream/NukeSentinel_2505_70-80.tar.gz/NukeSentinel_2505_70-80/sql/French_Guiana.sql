DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='gf';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3574603264, 3574603775, 1109653200, 'gf');
