DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='ls';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3301634048, 3301636095, 1136264118, 'ls');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3641670912, 3641671679, 1109653200, 'ls');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3645563136, 3645564671, 1109653200, 'ls');
