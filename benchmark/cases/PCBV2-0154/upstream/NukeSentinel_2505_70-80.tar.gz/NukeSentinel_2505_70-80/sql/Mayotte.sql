DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='yt';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3590311680, 3590311935, 1109653200, 'yt');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3653410048, 3653410063, 1109653200, 'yt');
