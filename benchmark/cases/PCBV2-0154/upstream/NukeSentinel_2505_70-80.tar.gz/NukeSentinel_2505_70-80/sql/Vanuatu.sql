DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='vu';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3394248704, 3394252799, 1109653200, 'vu');
