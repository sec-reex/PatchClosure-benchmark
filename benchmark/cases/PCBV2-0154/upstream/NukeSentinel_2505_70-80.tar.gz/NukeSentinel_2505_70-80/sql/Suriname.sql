DELETE FROM `nuke_nsnst_ip2country` WHERE `c2c`='sr';
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1118968320, 1118968575, 1109653200, 'sr');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (1118970880, 1118971520, 1109653200, 'sr');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3355548672, 3355549695, 1109653200, 'sr');
INSERT INTO `nuke_nsnst_ip2country` (`ip_lo`, `ip_hi`, `date`, `c2c`) VALUES (3355615232, 3355619327, 1109653200, 'sr');
