<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>__SITENAME__ is currently closed</title>
</head>
<body bgcolor="#000000" text="#FFFFFF" link="#FFFFFF">
<table align="center" width="75%"><tr><td>
<p align="center"><img src="abuse/logo.png" width="468" height="60" alt="" /><br /><b>We are currently closed for site and/or server updates and/or maintainance. Please check back often as this should not take long.</b></p>
<p align="center"><b>&nbsp;</b></p>
</td></tr></table>
</body>
</html>