<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>__SITENAME__: You have been blocked</title>
</head>
<body bgcolor="#000000" text="#FFFFFF" link="#FFFFFF">
<table align="center" width="75%"><tr><td>
<p align="center"><img src="abuse/logo.png" width="468" height="60" alt="" /><br /><b>You have been stopped from entering this site.</b></p>
<p align="center"><b>You have caused the flood protection of this site to be tripped. Wait a few seconds and try your request again.</b></p>
<p align="center"><b>If you think this is a mistake you can contact the site webmaster at <a href="mailto:__ADMINMAIL2__">__ADMINMAIL1__</a>.</b></p>
<p><b>Be SURE to include the following information in any email!</b><br />
<b>User Agent:</b> __USERAGENT__<br />
<b>Remote Address:</b> __REMOTEADDR__<br />
<b>Client IP:</b> __CLIENTIP__<br />
<b>Forwarded For:</b> __FORWARDEDFOR__<br />
<b>Date Blocked:</b> __TIMEDATE__</p></td></tr></table>
</body>
</html>