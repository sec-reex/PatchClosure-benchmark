<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

@set_time_limit(600);
$pagetitle = $pagename.": Upgrade 2.5.01 to 2.5.02";
include("header.php");
title("$pagetitle");
OpenTable();
echo "Operation Status!<br />\n";
echo "<hr />\n";
$message = "Everything seems to have completed successfully :)<br />\n";
// INSERT INTO nsnst_countries
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_countries` VALUES ('02', 'UnAllocated')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_countries failed<br />\n"; $message = ""; }
// ALTER nsnst_ip2country
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_ip2country` DROP `country`");
if(!$result) { echo "- Alter ".$prefix."_nsnst_ip2country failed<br />\n"; $message = ""; }
// INSERT INTO nsnst_config
$tms = time();
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('version_check', '$tms')");
if(!$result) { echo "- Insert to ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('version_newest', '2.5.02')");
if(!$result) { echo "- Insert to ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
// UPDATE nsnst_config
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='2.5.02' WHERE `config_name`='version_number'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$db->sql_query("ALTER TABLE `".$prefix."_nsnst_config` ORDER BY `config_name`");
$db->sql_query("OPTIMIZE TABLE `".$prefix."_nsnst_config`");
$db->sql_query("ALTER TABLE `".$prefix."_nsnst_countries` ORDER BY `c2c`");
$db->sql_query("OPTIMIZE TABLE `".$prefix."_nsnst_countries`");
echo "$message<hr />\n";
echo "Operation Complete!<br />\n";
echo "Click the link below to goto admin:<br />\n";
echo "Goto <a href=\"".$admin_file.".php?op=ABMain\">$pagename Admin</a>\n";
CloseTable();
include("footer.php");

?>