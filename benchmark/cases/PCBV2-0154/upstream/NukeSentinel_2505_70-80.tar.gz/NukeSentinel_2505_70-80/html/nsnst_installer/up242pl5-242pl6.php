<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

@set_time_limit(600);
$pagetitle = $pagename.": Upgrade 2.4.2pl5 to 2.4.2pl6";
include("header.php");
title("$pagetitle");
OpenTable();
echo "Operation Status!<br />\n";
echo "<hr />\n";
$message = "Everything seems to have completed successfully :)<br />\n";
// UPDATE TABLE nsnst_tracked_ips
$db->sql_query("DELETE FROM `".$prefix."_nsnst_tracked_ips` WHERE `page` LIKE '%&new_pass%'");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_tracked_ips` WHERE `page` LIKE '%&pass=%'");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_tracked_ips` WHERE `page` LIKE '%&password=%'");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_tracked_ips` WHERE `page` LIKE '%&pwd=%'");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_tracked_ips` WHERE `page` LIKE '%&user_password%'");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_tracked_ips` WHERE `page` LIKE '%&vpass=%'");
$db->sql_query("OPTIMIZE TABLE `".$prefix."_nsnst_tracked_ips`");
// UPDATE TABLE nsnst_ip2country
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=1493172224 AND `ip_hi`=1509949439");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=1224736768 AND `ip_hi`=1241513983");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=1275068416 AND `ip_hi`=1291845631");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=1509949440 AND `ip_hi`=1526726655");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=2030043136 AND `ip_hi`=2046820351");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=2046820352 AND `ip_hi`=2063597567");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=2063597568 AND `ip_hi`=2080374783");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=3170893824 AND `ip_hi`=3187671039");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=3198817280 AND `ip_hi`=3198817535");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=3288334336 AND `ip_hi`=3288334591");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=3289778176 AND `ip_hi`=3289778431");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=3291358464 AND `ip_hi`=3291358719");
$db->sql_query("ALTER TABLE `".$prefix."_nsnst_ip2country` ORDER BY `ip_lo`");
$db->sql_query("OPTIMIZE TABLE `".$prefix."_nsnst_ip2country`");
// UPDATE TABLE nsnst_countries
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_countries` VALUES ('ac', 'Ascension Island')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_countries failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_countries` VALUES ('ap', 'Aripo')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_countries failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_countries` VALUES ('gg', 'Guernsey')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_countries failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_countries` VALUES ('im', 'Isle Of Man')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_countries failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_countries` VALUES ('je', 'Jersey')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_countries failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_countries` VALUES ('tp', 'East Timor')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_countries failed<br />\n"; $message = ""; }
$db->sql_query("ALTER TABLE `".$prefix."_nsnst_countries` ORDER BY `c2c`");
$db->sql_query("OPTIMIZE TABLE `".$prefix."_nsnst_countries`");
// UPDATE TABLE nsnst_config
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='2.4.2pl6' WHERE `config_name`='version_number'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
echo "$message<hr />\n";
echo "Operation Complete!<br />\n";
echo "Click the link below to goto admin:<br />\n";
echo "Goto <a href=\"".$admin_file.".php?op=ABMain\">$pagename Admin</a>\n";
CloseTable();
include("footer.php");

?>