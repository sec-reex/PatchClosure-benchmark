<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

@set_time_limit(600);
$pagetitle = $pagename.": Upgrade 2.4.2x to 2.5.00";
include("header.php");
title("$pagetitle");
OpenTable();
echo "Operation Status!<br />\n";
echo "<hr />\n";
$message = "Everything seems to have completed successfully :)<br />\n";
// INSERT INTO nsnst_config
$db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name` = 'flood_del'");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name` = 'flood_delay_get'");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name` = 'flood_delay_post'");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name` = 'flood_max'");
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('ftaccess_path', '')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('flood_delay', '2')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('disable_switch', '0')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('track_clear', '0')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('blocked_clear', '0')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='2.5.00' WHERE `config_name`='version_number'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$db->sql_query("ALTER TABLE `".$prefix."_nsnst_config` ORDER BY `config_name`");
$db->sql_query("OPTIMIZE TABLE `".$prefix."_nsnst_config`");
// UPDATE TABLE nsnst_tracked_ips
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` ADD INDEX (`date`)");
if(!$result) { echo "- Add index ".$prefix."_nsnst_tracked_ips failed<br />\n"; $message = ""; }
// UPDATE TABLE nsnst_tracked_ips
$db->sql_query("DELETE FROM `".$prefix."_nsnst_tracked_ips` WHERE `page` LIKE '%&new_pass%'");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_tracked_ips` WHERE `page` LIKE '%&pass=%'");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_tracked_ips` WHERE `page` LIKE '%&password=%'");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_tracked_ips` WHERE `page` LIKE '%&pwd=%'");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_tracked_ips` WHERE `page` LIKE '%&user_password%'");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_tracked_ips` WHERE `page` LIKE '%&vpass=%'");
$db->sql_query("OPTIMIZE TABLE `".$prefix."_nsnst_tracked_ips`");
// UPDATE TABLE nsnst_ip2country
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=1493172224 AND `ip_hi`=1509949439");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=1224736768 AND `ip_hi`=1241513983");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=1275068416 AND `ip_hi`=1291845631");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=1509949440 AND `ip_hi`=1526726655");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=2030043136 AND `ip_hi`=2046820351");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=2046820352 AND `ip_hi`=2063597567");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=2063597568 AND `ip_hi`=2080374783");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=3170893824 AND `ip_hi`=3187671039");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=3198817280 AND `ip_hi`=3198817535");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=3288334336 AND `ip_hi`=3288334591");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=3289778176 AND `ip_hi`=3289778431");
$db->sql_query("DELETE FROM `".$prefix."_nsnst_ip2country` WHERE `ip_lo`=3291358464 AND `ip_hi`=3291358719");
$db->sql_query("ALTER TABLE `".$prefix."_nsnst_ip2country` ORDER BY `ip_lo`");
$db->sql_query("OPTIMIZE TABLE `".$prefix."_nsnst_ip2country`");
// UPDATE TABLE nsnst_countries
if($db->sql_numrows($db->sql_query("SELECT * FROM `".$prefix."_nsnst_countries` WHERE `c2c`='ac'")) < 1) {
  $result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_countries` VALUES ('ac', 'Ascension Island')");
  if(!$result) { echo "- Insert into ".$prefix."_nsnst_countries failed<br />\n"; $message = ""; }
}
if($db->sql_numrows($db->sql_query("SELECT * FROM `".$prefix."_nsnst_countries` WHERE `c2c`='ap'")) < 1) {
  $result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_countries` VALUES ('ap', 'Aripo')");
  if(!$result) { echo "- Insert into ".$prefix."_nsnst_countries failed<br />\n"; $message = ""; }
}
if($db->sql_numrows($db->sql_query("SELECT * FROM `".$prefix."_nsnst_countries` WHERE `c2c`='gg'")) < 1) {
  $result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_countries` VALUES ('gg', 'Guernsey')");
  if(!$result) { echo "- Insert into ".$prefix."_nsnst_countries failed<br />\n"; $message = ""; }
}
if($db->sql_numrows($db->sql_query("SELECT * FROM `".$prefix."_nsnst_countries` WHERE `c2c`='im'")) < 1) {
  $result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_countries` VALUES ('im', 'Isle Of Man')");
  if(!$result) { echo "- Insert into ".$prefix."_nsnst_countries failed<br />\n"; $message = ""; }
}
if($db->sql_numrows($db->sql_query("SELECT * FROM `".$prefix."_nsnst_countries` WHERE `c2c`='je'")) < 1) {
  $result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_countries` VALUES ('je', 'Jersey')");
  if(!$result) { echo "- Insert into ".$prefix."_nsnst_countries failed<br />\n"; $message = ""; }
}
if($db->sql_numrows($db->sql_query("SELECT * FROM `".$prefix."_nsnst_countries` WHERE `c2c`='tp'")) < 1) {
  $result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_countries` VALUES ('tp', 'East Timor')");
  if(!$result) { echo "- Insert into ".$prefix."_nsnst_countries failed<br />\n"; $message = ""; }
}
$db->sql_query("ALTER TABLE `".$prefix."_nsnst_countries` ORDER BY `c2c`");
$db->sql_query("OPTIMIZE TABLE `".$prefix."_nsnst_countries`");
// DROP TABLE nsnst_flood
if($db->sql_numrows($db->sql_query("SHOW TABLES LIKE '".$prefix."_nsnst_flood'")) > 0) {
  $result = $db->sql_query("DROP TABLE `".$prefix."_nsnst_flood`");
  if(!$result) { echo "- Drop ".$prefix."_nsnst_flood failed<br />\n"; $message = ""; }
}
// UPDATE TABLE nsnst_blocked_ips
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_blocked_ips` ADD `ip_long` INT(10) unsigned NOT NULL default '0' AFTER `ip_addr`");
if(!$result) { echo "- ALTER TABLE ".$prefix."_nsnst_blocked_ips<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_blocked_ips` ADD INDEX (`ip_long`)");
if(!$result) { echo "- ADD Index ".$prefix."_nsnst_blocked_ips<br />\n"; $message = ""; }
// UPDATE TABLE nsnst_tracked_ips
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` CHANGE `hostname` `ip_long` INT(10) unsigned NOT NULL default '0'");
if(!$result) { echo "- ALTER TABLE ".$prefix."_nsnst_tracked_ips<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` ADD INDEX (`ip_long`)");
if(!$result) { echo "- ADD Index ".$prefix."_nsnst_tracked_ips<br />\n"; $message = ""; }
// UPDATE TABLE nsnst_blocked_ips
$importad = $db->sql_query("SELECT `ip_addr` FROM `".$prefix."_nsnst_blocked_ips`");
while(list($b_ip) = $db->sql_fetchrow($importad)) {
  $bantemp = str_replace("*", "0", $b_ip);
  $xIPl = sprintf("%u", ip2long($bantemp));
  $db->sql_query("UPDATE `".$prefix."_nsnst_blocked_ips` SET `ip_long`='$xIPl' WHERE `ip_addr`='$b_ip'");
}
// UPDATE TABLE nsnst_tracked_ips
$importad = $db->sql_query("SELECT DISTINCT(`ip_addr`) FROM `".$prefix."_nsnst_tracked_ips`");
while(list($b_ip) = $db->sql_fetchrow($importad)) {
  $bantemp = str_replace("*", "0", $b_ip);
  $xIPl = sprintf("%u", ip2long($bantemp));
  $db->sql_query("UPDATE `".$prefix."_nsnst_tracked_ips` SET `ip_long`='$xIPl' WHERE `ip_addr`='$b_ip'");
}
echo "$message<hr />\n";
echo "Operation Complete!<br />\n";
echo "Click the link below to goto admin:<br />\n";
echo "Goto <a href=\"".$admin_file.".php?op=ABMain\">$pagename Admin</a>\n";
CloseTable();
include("footer.php");

?>