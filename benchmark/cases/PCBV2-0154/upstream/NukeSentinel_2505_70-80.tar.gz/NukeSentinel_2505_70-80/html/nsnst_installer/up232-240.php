<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

@set_time_limit(600);
$pagetitle = $pagename.": Upgrade 2.3.2 to 2.4.0";
include("header.php");
title("$pagetitle");
OpenTable();
echo "Operation Status!<br />\n";
echo "<hr />\n";
$message = "Everything seems to have completed successfully :)<br />\n";
// CORRECT TABLE nsnst_config
$nefig = $db->sql_fetchrow($db->sql_query("SELECT `config_value` FROM `".$prefix."_nsnst_config` WHERE `config_name`='lookup_link'"));
if(stristr($nefig['lookup_link'] , 'cache=off')) {
  $result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='http://www.DNSstuff.com/tools/whois.ch?ip=' WHERE `config_name`='lookup_link'");
  if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
}
// TRANDSFER TABLE nsnst_reserved_ranges
$result = $db->sql_query("SELECT * FROM `".$prefix."_nsnst_reserved_ranges`");
while($row = $db->sql_fetchrow($result)) {
  $result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_ip2country` VALUES ('".$row['ip_lo']."', '".$row['ip_hi']."', '".$row['date']."', '".$row['c2c']."', 'IANA Reserved'");
  if(!$result) { echo "- Insert into ".$prefix."_nsnst_ip2country failed<br />\n"; $message = ""; }
}
// REMOVE TABLE nsnst_reserved_ranges
$result = $db->sql_query("DROP TABLE `".$prefix."_nsnst_reserved_ranges`");
if(!$result) { echo "- Destall ".$prefix."_nsnst_reserved_ranges failed<br />\n"; $message = ""; }
// INSERT INTO nsnst_countries
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_countries` VALUES ('ax', 'Aaland Islands')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_countries failed<br />\n"; $message = ""; }
// UPDATE TABLE nsnst_config
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='2.4.0' WHERE `config_name`='version_number'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
echo "$message<hr />\n";
echo "Operation Complete!<br />\n";
echo "Click the link below to goto admin:<br />\n";
echo "<b>NOTE:</b> Reserved Ranges are now stored in your IP 2 Country table!<br />\n";
echo "Goto <a href=\"".$admin_file.".php?op=ABMain\">$pagename Admin</a>\n";
CloseTable();
include("footer.php");

?>