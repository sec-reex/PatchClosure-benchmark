<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

@set_time_limit(600);
$pagetitle = $pagename.": Upgrade 2.3.1 to 2.3.2";
include("header.php");
title("$pagetitle");
OpenTable();
echo "Operation Status!<br />\n";
echo "<hr />\n";
$message = "Everything seems to have completed successfully :)<br />\n";
// UPDATE TABLE nsnst_config
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='2.3.2' WHERE `config_name`='version_number'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
// INSERT INTO TABLE nsnst_config
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('flood_delay_post', '2')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('flood_delay_get', '2')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
// INSERT INTO TABLE nsnst_blockers
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_blockers` VALUES (11, 'flood', 0, 1, 2, '', 'Abuse-Flood', 'abuse_flood.tpl', 0, 1, '')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_blockers failed<br />\n"; $message = ""; }
// CREATE TABLE nsnst_flood
$result = $db->sql_query("CREATE TABLE `".$prefix."_nsnst_flood` (`ip` varchar(15) NOT NULL default '0.0.0.0', `lastpost` int(20) NOT NULL default '0', PRIMARY KEY (`ip`))");
if(!$result) { echo "- Create ".$prefix."_nsnst_flood failed<br />\n"; $message = ""; }
echo "$message<hr />\n";
echo "Operation Complete!<br />\n";
echo "Click the link below to goto admin:<br />\n";
echo "Goto <a href=\"".$admin_file.".php?op=ABMain\">$pagename Admin</a>\n";
CloseTable();
include("footer.php");

?>