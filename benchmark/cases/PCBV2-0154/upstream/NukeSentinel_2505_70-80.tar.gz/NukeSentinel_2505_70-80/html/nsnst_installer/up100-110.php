<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

$pagetitle = $pagename.": Upgrade 1.0.0 to 1.1.0";
include("header.php");
title("$pagetitle");
OpenTable();
echo "Operation Status!<br />\n";
echo "<hr />\n";
$message = "Everything seems to have completed successfully :)<br />\n";
$ab_config = $db->sql_fetchrow($db->sql_query("SELECT * FROM `".$prefix."_nsnst_config`"));
$result = $db->sql_query("DROP TABLE `".$prefix."_nsnst_config`");
if(!$result) { echo "- Dropped ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("CREATE TABLE `".$prefix."_nsnst_config` (`config_name` varchar(255) NOT NULL default '', `config_value` longtext NOT NULL, PRIMARY KEY (`config_name`))");
if(!$result) { echo "- Re-Create ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('forward_loc', '".$ab_config['forward_loc']."')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('pc_killer', '".$ab_config['pc_killer']."')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
if($ab_config['pc_killer_loop'] == 0) { $ab_config['pc_killer_loop'] = "True"; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('pc_killer_loop', '".$ab_config['pc_killer_loop']."')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('ban_type', '".$ab_config['ban_type']."')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('harvestlist', '".$ab_config['harvestlist']."')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('perpage', '".$ab_config['perpage']."')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('htapath', '".$ab_config['htapath']."')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('act_harvest', '".$ab_config['act_harvest']."')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('act_union', '".$ab_config['act_union']."')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('act_clike', '".$ab_config['act_clike']."')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('act_script', '".$ab_config['act_script']."')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('act_authors', '".$ab_config['act_authors']."')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('act_filters', '2')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('email_lookup', '0')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_config` ORDER BY `config_name`");
if(!$result) { echo "- Adjust Order ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
echo "$message<hr />\n";
echo "Operation Complete!<br />\n";
echo "Goto <a href=\"".$admin_file.".php?op=ABConfig\">$pagename Config</a>\n";
CloseTable();
include("footer.php");

?>