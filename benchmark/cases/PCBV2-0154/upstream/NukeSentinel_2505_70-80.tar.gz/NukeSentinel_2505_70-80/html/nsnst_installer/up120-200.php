<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

$pagetitle = $pagename.": Upgrade 1.2.0 to 2.0.0 RC 4";
include("header.php");
title("$pagetitle");
OpenTable();
echo "Operation Status!<br />\n";
echo "<hr />\n";
$message = "Everything seems to have completed successfully :)<br />\n";
list($harvestlisting) = $db->sql_fetchrow($db->sql_query("SELECT `config_value` FROM `".$prefix."_nsnst_config` WHERE `config_name` = 'harvestlist'"));
// CREATE TABLE nsnst_admins
$result = $db->sql_query("CREATE TABLE `".$prefix."_nsnst_admins` (`aid` varchar(25) NOT NULL default '', `login` varchar(25) NOT NULL default '', `passwd` varchar(40) NOT NULL default '', `protected` tinyint(2) NOT NULL default '0', `is_god` tinyint(1) NOT NULL default '0', PRIMARY KEY (`aid`))");
if(!$result) { echo "- Create ".$prefix."_nsnst_admins failed<br />\n"; $message = ""; }
// POPULATE TABLE nsnst_admins
$importad = $db->sql_query("SELECT `aid`, `name`, `pwd` FROM `".$prefix."_authors`");
while(list($a_aid, $a_name, $a_pwd) = $db->sql_fetchrow($importad)) {
    if(strtolower($a_name) == "god") { $is_god = 1; } else { $is_god = 0; }
    $result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_admins` VALUES ('$a_aid', '$a_aid', '$a_pwd', '$is_god', '$is_god')");
    if(!$result) { echo "- Import into ".$prefix."_nsnst_admins failed<br />\n"; }
}
// CREATE TABLE nsnst_blockers
$result = $db->sql_query("CREATE TABLE `".$prefix."_nsnst_blockers` (`blocker` int(4) NOT NULL default '', `block_name` varchar(20) NOT NULL default '', `activate` int(4) NOT NULL default '0', `block_type` int(4) NOT NULL default '0', `email_lookup` int(4) NOT NULL default '0', `forward` varchar(255) NOT NULL default '', `reason` varchar(20) NOT NULL default '', `template` varchar(255) NOT NULL default '', `duration` int(20) NOT NULL default '0', `htaccess` int(4) NOT NULL default '0', `list` longtext NOT NULL, PRIMARY KEY (`blocker`))");
if(!$result) { echo "- Create ".$prefix."_nsnst_blockers failed<br />\n"; $message = ""; }
// INSERT INTO TABLE nsnst_blockers
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_blockers` VALUES (0, 'other', 0, 0, 0, '', 'Abuse-Other', 'abuse_default.tpl', 0, 0, '')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_blockers failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_blockers` VALUES (1, 'union', 0, 0, 0, '', 'Abuse-Union', 'abuse_union.tpl', 0, 0, '')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_blockers failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_blockers` VALUES (2, 'clike', 0, 0, 0, '', 'Abuse-CLike', 'abuse_clike.tpl', 0, 0, '')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_blockers failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_blockers` VALUES (3, 'harvester', 0, 0, 0, '', 'Abuse-Harvest', 'abuse_harvester.tpl', 0, 0, '$harvestlisting')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_blockers failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_blockers` VALUES (4, 'script', 0, 0, 0, '', 'Abuse-Script', 'abuse_script.tpl', 0, 0, '')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_blockers failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_blockers` VALUES (5, 'author', 0, 0, 0, '', 'Abuse-Author', 'abuse_author.tpl', 0, 0, '')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_blockers failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_blockers` VALUES (6, 'referer', 0, 0, 0, '', 'Abuse-Referer', 'abuse_referer.tpl', 0, 0, '121hr.com\r\n1st-call.net\r\n1stcool.com\r\n5000n.com\r\n69-xxx.com\r\n9uy.com\r\na-day-at-the-party.com\r\naccessthepeace.com\r\nadult-sex-toys-free-porn.com\r\nalfonssackpfeiffe.com\r\nalongwayfrommars.com\r\nanime-sex-1.com\r\nanorex-sf-stimulant-free.com\r\nantibot.net\r\nantique-tokiwa.com\r\napotheke-heute.com\r\narmada31.com\r\nascendbtg.com\r\naschalaecheck.com\r\nasian-sex-free-sex.com\r\naslowspeeker.com\r\nassasinatedfrogs.com\r\nathirst-for-tranquillity.net\r\naubonpanier.com\r\navalonumc.com\r\nbbw4phonesex.com\r\nbeersarenotfree.com\r\nbierikiuetsch.com\r\nblack-pussy-toon-clip-anal-lover-single.com\r\nblownapart.com\r\nblueroutes.com\r\nboasex.com\r\nbooksandpages.com\r\nbootyquake.com\r\nbossyhunter.com\r\nboyz-sex.com\r\nbrokersaandpokers.com\r\nbrowserwindowcleaner.com\r\nbudobytes.com\r\nbusiness2fun.com\r\nbyuntaesex.com\r\ncaniputsomeloveintoyou.com\r\ncartoons.net.ru\r\ncaverunsailing.com\r\ncertainhealth.com\r\nclantea.com\r\nclose-protection-services.com\r\nclubcanino.com\r\nclubstic.com\r\ncobrakai-skf.com\r\ncollegefucktour.co.uk\r\ncommanderspank.com\r\ncoolenabled.com\r\ncrusecountryart.com\r\ncrusingforsex.co.uk\r\ncunt-twat-pussy-juice-clit-licking.com\r\ncustomerhandshaker.com\r\ndarkprofits.co.uk\r\ndatingforme.co.uk\r\ndatingmind.com\r\ndegree.org.ru\r\ndelorentos.com\r\ndinkydonkyaussie.com\r\ndjpritchard.com\r\ndraufgeschissen.com\r\ndreamerteens.co.uk\r\nebonyplaya.co.uk\r\necobuilder2000.com\r\nemailandemail.com\r\nemedici.net\r\nengine-on-fire.com\r\nerocity.co.uk\r\nesport3.com\r\neteenbabes.com\r\neurofreepages.com\r\neurotexans.com\r\nevolucionweb.com\r\nfakoli.com\r\nfe4ba.com\r\nferienschweden.com\r\nfirsttimeteadrinker.com\r\nfishing.net.ru\r\nflatwonkers.com\r\nflowershopentertainment.com\r\nflymario.com\r\nfree-xxx-pictures-porno-gallery.com\r\nfreebestporn.com\r\nfreexxxstuff.co.uk\r\nfruitologist.net\r\nfruitsandbolts.com\r\nfuck-cumshots-free-midget-movie-clips.com\r\nfuck-michaelmoore.com\r\ngadless.com\r\ngallapagosrangers.com\r\ngalofu.com\r\ngaypixpost.co.uk\r\ngeomasti.com\r\ngirltime.co.uk\r\nglassrope.com\r\ngoldenageresort.com\r\ngonnabedaddies.com\r\nguardingtheangels.com\r\nguyprofiles.co.uk\r\nhappy1225.com\r\nhappychappywacky.com\r\nhealth.org.ru\r\nhexplas.com\r\nhillsweb.com\r\nhiptuner.com\r\nhoa-tuoi.com\r\nhomebuyinginatlanta.com\r\nhorizonultra.com\r\nhorseminiature.net\r\nhotkiss.co.uk\r\nhotlivegirls.co.uk\r\nhusler.co.uk\r\niamnotsomeone.com\r\niconsofcorruption.com\r\nihavenotrustinyou.com\r\ninformat-systems.com\r\ninteriorproshop.com\r\nintersoftnetworks.com\r\ninthecrib.com\r\ninvestment4cashiers.com\r\niti-trailers.com\r\njacks-world.com\r\njamesthesailorbasher.com\r\njesuislemonds.com\r\njustanotherdomainname.com\r\nkampelicka.com\r\nkanalrattenarsch.com\r\nkatzasher.com\r\nkerosinjunkie.com\r\nkoenigspisser.com\r\nkontorpara.com\r\nl8t.com\r\nlaestacion101.com\r\nlambuschlamppen.com\r\nlankasex.co.uk\r\nlaser-creations.com\r\nle-tour-du-monde.com\r\nlecraft.com\r\nledo-design.com\r\nleftregistration.com\r\nlekkikoomastas.com\r\nlepommeau.com\r\nlibr-animal.com\r\nlibraries.org.ru\r\nlikewaterlikewind.com\r\nlimbojumpers.com\r\nlink.ru\r\nlockportlinks.com\r\nloiproject.com\r\nlongtermalternatives.com\r\nlottoeco.com\r\nlucalozzi.com\r\nmaki-e-pens.com\r\nmalepayperview.co.uk\r\nmangaxoxo.com\r\nmaps.org.ru\r\nmarcofields.com\r\nmasterofcheese.com\r\nmasteroftheblasterhill.com\r\nmastheadwankers.com\r\nmegafrontier.com\r\nmeinschuppen.com\r\nmercurybar.com\r\nmetapannas.com\r\nmicelebre.com\r\nmidnightlaundries.com\r\nmikeapartment.co.uk\r\nmimundial2002.com\r\nmixtaperadio.com\r\nmondialcoral.com\r\nmonja-wakamatsu.com\r\nmonstermonkey.net\r\nmouthfreshners.com\r\nmullensholiday.com\r\nmusilo.com\r\nmyhollowlog.com\r\nmyhomephonenumber.com\r\nmykeyboardisbroken.com\r\nmysofia.net\r\nnaked-cheaters.com\r\nnaked-old-women.com\r\nnastygirls.co.uk\r\nnatterratter.com\r\nnaughtyadam.com\r\nnestbeschmutzer.com\r\nnewrealeaseonline.com\r\nnewrealeasesonline.com\r\nnextfrontiersonline.com\r\nnikostaxi.com\r\nnotorious7.com\r\nnrecruiter.com\r\nnursingdepot.com\r\nnustramosse.com\r\nnuturalhicks.com\r\noccaz-auto49.com\r\nocean-db.net\r\noilburnerservice.net\r\nomburo.com\r\noneoz.com\r\nonepageahead.net\r\nonlinewithaline.com\r\norganizate.net\r\nourownweddingsong.com\r\nowen-music.com\r\np-partners.com\r\npaginadeautor.com\r\npakistandutyfree.com\r\npamanderson.co.uk\r\nparentsense.net\r\nparticlewave.net\r\npay4link.net\r\npcisp.com\r\npersist-pharma.com\r\npetplusindia.com\r\npickabbw.co.uk\r\npicture-oral-position-lesbian.com\r\npl8again.com\r\nplaneting.net\r\npopusky.com\r\nporn-expert.com\r\npromoblitza.com\r\nproproducts-usa.com\r\nptcgzone.com\r\nputtingtogether.com\r\nqualifiedcancelations.com\r\nrahost.com\r\nrainbow21.com\r\nrandomfeeding.com\r\nrape-art.com\r\nrd-brains.com\r\nrealestateonthehill.net\r\nrequested-stuff.com\r\nricopositive.com\r\nrisorseinrete.com\r\nrotatingcunts.com\r\nrunawayclicks.com\r\nrutalibre.com\r\ns-marche.com\r\nsabrosojazz.com\r\nsasseminars.com\r\nschlampenbruzzler.com\r\nsearchmybong.com\r\nseckur.com\r\nsex-asian-porn-interracial-photo.com\r\nsex-porn-fuck-hardcore-movie.com\r\nsexa3.net\r\nsexer.com\r\nsexintention.com\r\nsexomundo.com\r\nshop-toon-hardcore-fuck-cum-pics.com\r\nsilverfussions.com\r\nsin-city-sex.net\r\nsluisvan.com\r\nsnagglersmaggler.com\r\nsophiesplace.net\r\nsoursushi.com\r\nsouthernxstables.com\r\nspeedpal4you.com\r\nsporty.org.ru\r\nstopdriving.net\r\nstw.org.ru\r\nsufficientlife.com\r\nsussexboats.net\r\nswinger-party-free-dating-porn-sluts.com\r\nsydneyhay.com\r\nszmjht.com\r\nteninchtrout.com\r\nthebalancedfruits.com\r\ntheendofthesummit.com\r\nthiswillbeit.com\r\nthosethosethose.com\r\nticyclesofindia.com\r\ntonius.com\r\ntoohsoft.com\r\ntoolvalley.com\r\ntooporno.net\r\ntoosexual.com\r\ntorngat.com\r\ntour.org.ru\r\ntowneluxury.com\r\ntriacoach.net\r\ntrottinbob.com\r\ntttframes.com\r\ntvjukebox.net\r\nundercvr.com\r\nunfinished-desires.com\r\nunicornonero.com\r\nunionvillefire.com\r\nupsandowns.com\r\nupthehillanddown.com\r\nvallartavideo.com\r\nvietnamdatingservices.com\r\nvinegarlemonshots.com\r\nvizy.net.ru\r\nvnladiesdatingservices.com\r\nvomitandbusted.com\r\nwalkingthewalking.com\r\nwell-I-am-the-type-of-boy.com\r\nwhincer.net\r\nwhitpagesrippers.com\r\nwipperrippers.com\r\nwordfilebooklets.com\r\nxxxchyangel.com\r\nxxxzips.com\r\nyouarelostintransit.com\r\nyuppieslovestocks.com\r\nyuzhouhuagong.com\r\nzhaori-food.com\r\nzwiebelbacke.com')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_blockers failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_blockers` VALUES (7, 'filter', 0, 0, 0, '', 'Abuse-Filter', 'abuse_filter.tpl', 0, 0, '')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_blockers failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_blockers` VALUES (8, 'request', 0, 0, 0, '', 'Abuse-Request', 'abuse_request.tpl', 0, 0, '')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_blockers failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_blockers` VALUES (9, 'string', 0, 0, 0, '', 'Abuse-String', 'abuse_string.tpl', 0, 0, '')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_blockers failed<br />\n"; $message = ""; }
// UPDATE TABLE nsnst_ips
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_ips` ADD `expires` int(20) NOT NULL default '0'");
if(!$result) { echo "- Add field (expires) ".$prefix."_nsnst_ips failed<br />\n"; $message = ""; }
// UPDATE TABLE nsnst_config
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_name`='htaccess_path' WHERE `config_name`='htapath'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_name`='display_link' WHERE `config_name`='dis_link'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_name`='display_reason' WHERE `config_name`='dis_reason'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_config` DROP PRIMARY KEY, ADD PRIMARY KEY (`config_name`)");
if(!$result) { echo "- Add Key ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_config` CHANGE `config_value` `config_value` LONGTEXT NOT NULL");
if(!$result) { echo "- Alter ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
// INSERT INTO TABLE nsnst_config
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('http_auth', '0')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('site_reason', '<HTML>\r\n<HEAD>\r\n<TITLE>NukeSentinel� || Site Currently Offline</title>\r\n</head>\r\n<BODY LINK=\"#0000ff\" VLINK=\"#800080\" BGCOLOR=\"#ffffff\">\r\n\r\n<center><FONT FACE=\"Arial\" SIZE=\"2\"><b>We apologize, we are currently offline for site maintainance. Sorry for the inconvenience. We should be back on soon.</b></font></center>\r\n</html>')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('site_switch', '0')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('sort_column', 'date')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('sort_direction', 'desc')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('version_number', '2.0.0 RC 4')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
// REMOVE FROM TABLE nsnst_config
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='act_authors'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='act_clike'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='act_filters'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='act_harvest'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='act_script'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='act_union'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='ban_type'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='forward_loc'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='harvestlist'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='email_lookup'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
// OPTIMIZE TABLES
$result = $db->sql_query("OPTIMIZE TABLE `".$prefix."_nsnst_config`");
if(!$result) { echo "- Optimize Table ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("OPTIMIZE TABLE `".$prefix."_nsnst_ips`");
if(!$result) { echo "- Optimize Table ".$prefix."_nsnst_ips failed<br />\n"; $message = ""; }
// INSERT INTO TABLE nsnst_config
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('self_expire', '0')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('allow_proxy', '0')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('proxy_reason', '<HTML>\r\n<HEAD>\r\n<TITLE>NukeSentinel� || Proxies are Blocked</title>\r\n</head>\r\n<BODY LINK=\"#0000ff\" VLINK=\"#800080\" BGCOLOR=\"#ffffff\">\r\n\r\n<center><FONT FACE=\"Arial\" SIZE=\"2\"><b>We do not allow proxy connections to our site.</b></font></center>\r\n</html>')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
// UPDATE TABLE nsnst_admins
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_admins` DROP `is_god`");
if(!$result) { echo "- Drop Field ".$prefix."_nsnst_admins failed<br />\n"; $message = ""; }
// OPTIMIZE TABLES
$result = $db->sql_query("OPTIMIZE TABLE `".$prefix."_nsnst_config`");
if(!$result) { echo "- Optimize Table ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
// INSERT INTO TABLE nsnst_config
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('prevent_dos', '0')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
// UPDATE TABLE nsnst_config
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='admin_proxy_reason.tpl' WHERE `config_name`='proxy_reason'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='admin_site_reason.tpl' WHERE `config_name`='site_reason'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_config` ORDER BY `config_name`");
if(!$result) { echo "- Adjust Order ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
// INSERT INTO TABLE nsnst_config
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('force_nukeurl', '0')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('help_switch', '0')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
// UPDATE TABLE nsnst_config
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_name`='proxy_switch' WHERE `config_name`='allow_proxy'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='2.0.0' WHERE `config_name`='version_number'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_config` ORDER BY `config_name`");
if(!$result) { echo "- Adjust Order ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
// OPTIMIZE TABLES
$result = $db->sql_query("OPTIMIZE TABLE `".$prefix."_nsnst_config`");
if(!$result) { echo "- Optimize Table ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
echo "$message<hr />\n";
echo "Operation Complete!<br />\n";
echo "This upgrade introduces a new Blocker for Referers.<br />\n";
echo "All blockers have been turned off due to setting's values being changed.<br />\n";
echo "Click the link below to reset the blockers:<br />\n";
echo "Goto <a href=\"".$admin_file.".php?op=ABConfig\">$pagename Config</a>\n";
CloseTable();
include("footer.php");

?>