<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

@set_time_limit(600);
$pagetitle = $pagename.": Upgrade 2.4.0a to 2.4.0b";
include("header.php");
title("$pagetitle");
OpenTable();
echo "Operation Status!<br />\n";
echo "<hr />\n";
$message = "Everything seems to have completed successfully :)<br />\n";
// UPDATE TABLE INDEXING
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_blocked_ips` ADD INDEX (`c2c`), ADD INDEX (`date`), ADD INDEX (`expires`), ADD INDEX (`reason`)");
if(!$result) { echo "- Update ".$prefix."_nsnst_blocked_ips Keys failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_blocked_ranges` DROP INDEX `code`, ADD PRIMARY KEY (`ip_lo` , `ip_hi`), ADD INDEX (`c2c`), ADD INDEX (`date`), ADD INDEX (`expires`), ADD INDEX (`reason`)");
if(!$result) { echo "- Update ".$prefix."_nsnst_blocked_ranges Keys failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_countries` DROP INDEX `c2c`, ADD PRIMARY KEY (`c2c`)");
if(!$result) { echo "- Update ".$prefix."_nsnst_countries Keys failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_excluded_ranges` DROP INDEX `code`, ADD PRIMARY KEY (`ip_lo` , `ip_hi`), ADD INDEX (`c2c`), ADD INDEX (`date`)");
if(!$result) { echo "- Update ".$prefix."_nsnst_excluded_ranges Keys failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_ip2country` DROP INDEX `code`, ADD PRIMARY KEY (`ip_lo` , `ip_hi`), ADD INDEX (`c2c`), ADD INDEX (`date`)");
if(!$result) { echo "- Update ".$prefix."_nsnst_ip2country Keys failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_protected_ranges` DROP INDEX `code`, ADD PRIMARY KEY (`ip_lo` , `ip_hi`), ADD INDEX (`c2c`), ADD INDEX (`date`)");
if(!$result) { echo "- Update ".$prefix."_nsnst_protected_ranges Keys failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` DROP INDEX `maintracking`, DROP INDEX `tid`, ADD INDEX (`c2c`), ADD INDEX (`ip_addr`), ADD INDEX (`user_id`), ADD INDEX (`username`)");
if(!$result) { echo "- Update ".$prefix."_nsnst_tracked_ips Keys failed<br />\n"; $message = ""; }
// UPDATE TABLE nsnst_config
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='2.4.0b' WHERE `config_name`='version_number'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
echo "$message<hr />\n";
echo "Operation Complete!<br />\n";
echo "Click the link below to goto admin:<br />\n";
echo "<b>NOTE:</b> This revision has updated the table indexes to run quicker!<br />\n";
echo "Goto <a href=\"".$admin_file.".php?op=ABMain\">$pagename Admin</a>\n";
CloseTable();
include("footer.php");

?>