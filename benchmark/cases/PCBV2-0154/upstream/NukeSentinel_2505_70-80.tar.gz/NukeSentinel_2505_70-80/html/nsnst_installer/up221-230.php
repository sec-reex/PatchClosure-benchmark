<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

@set_time_limit(600);
$pagetitle = $pagename.": Upgrade 2.2.1 to 2.3.0";
include("header.php");
title("$pagetitle");
OpenTable();
echo "Operation Status!<br />\n";
echo "<hr />\n";
$message = "Everything seems to have completed successfully :)<br />\n";
// UPDATE TABLE nsnst_config
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='2.3.0' WHERE `config_name`='version_number'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_config` ORDER BY `config_name`");
if(!$result) { echo "- Adjust Order ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
// CREATE TABLE nsnst_cidrs
$result = $db->sql_query("CREATE TABLE IF NOT EXISTS `".$prefix."_nsnst_cidrs` (`cidr` int(2) NOT NULL default '0', `hosts` int(10) NOT NULL default '0', `mask` varchar(15) NOT NULL default '', PRIMARY KEY (`cidr`))");
if(!$result) { echo "- Create ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
// INSERT INTO TABLE nsnst_cidrs
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (1, 2147483647, '127.255.255.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (2, 1073741824, '63.255.255.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (3, 536870912, '31.255.255.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (4, 268435456, '15.255.255.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (5, 134217728, '7.255.255.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (6, 67108864, '3.255.255.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (7, 33554432, '1.255.255.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (8, 16777216, '0.255.255.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (9, 8388608, '0.127.255.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (10, 4194304, '0.63.255.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (11, 2097152, '0.31.255.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (12, 1048576, '0.15.255.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (13, 524288, '0.7.255.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (14, 262144, '0.3.255.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (15, 131072, '0.1.255.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (16, 65536, '0.0.255.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (17, 32768, '0.0.127.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (18, 16384, '0.0.63.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (19, 8192, '0.0.31.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (20, 4096, '0.0.15.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (21, 2048, '0.0.7.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (22, 1024, '0.0.3.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (23, 512, '0.0.1.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (24, 256, '0.0.0.255')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (25, 128, '0.0.0.127')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (26, 64, '0.0.0.63')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (27, 32, '0.0.0.31')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (28, 16, '0.0.0.15')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (29, 8, '0.0.0.7')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (30, 4, '0.0.0.3')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (31, 2, '0.0.0.1')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_cidrs` VALUES (32, 1, '0.0.0.0')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
echo "$message<hr />\n";
echo "Operation Complete!<br />\n";
echo "Click the link below to goto admin:<br />\n";
echo "Goto <a href=\"".$admin_file.".php?op=ABMain\">$pagename Admin</a>\n";
CloseTable();
include("footer.php");

?>