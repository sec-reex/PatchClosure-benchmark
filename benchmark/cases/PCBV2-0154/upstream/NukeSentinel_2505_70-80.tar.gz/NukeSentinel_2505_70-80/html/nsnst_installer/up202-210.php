<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

$pagetitle = $pagename.": Upgrade 2.0.2 to 2.1.0";
include("header.php");
title("$pagetitle");
OpenTable();
echo "Operation Status!<br />\n";
echo "<hr />\n";
$message = "Everything seems to have completed successfully :)<br />\n";
// ALTER TABLE nsnst_blocked_ips
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_ips` RENAME `".$prefix."_nsnst_blocked_ips`");
if(!$result) { echo "- Alter ".$prefix."_nsnst_ips failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_blocked_ips` ADD `c2c` CHAR(2) DEFAULT '00' NOT NULL");
if(!$result) { echo "- Alter ".$prefix."_nsnst_blocked_ips failed<br />\n"; $message = ""; }
       // CREATE TABLE nsnst_blocked_ranges
$result = $db->sql_query(" CREATE TABLE `".$prefix."_nsnst_blocked_ranges` (`ip_lo` int(10) unsigned NOT NULL default '0', `ip_hi` int(10) unsigned NOT NULL default '0', `date` varchar(20) NOT NULL default '0', `notes` text NOT NULL, `reason` tinyint(1) NOT NULL default '0', `expires` int(20) NOT NULL default '0', `c2c` char(2) NOT NULL default '00', KEY `code` (`ip_lo`, `ip_hi`, `c2c`))");
if(!$result) { echo "- Create ".$prefix."_nsnst_blocked_ranges failed<br />\n"; $message = ""; }
// CREATE TABLE nsnst_excluded_ranges
$result = $db->sql_query("CREATE TABLE `".$prefix."_nsnst_excluded_ranges` (`ip_lo` int(10) unsigned NOT NULL default '0', `ip_hi` int(10) unsigned NOT NULL default '0', `date` varchar(20) NOT NULL default '0', `notes` text NOT NULL, `c2c` char(2) NOT NULL default '00', KEY `code` (`ip_lo`, `ip_hi`, `c2c`))");
if(!$result) { echo "- Create ".$prefix."_nsnst_excluded_ranges failed<br />\n"; $message = ""; }
// CREATE TABLE nsnst_protected_ranges
$result = $db->sql_query("CREATE TABLE `".$prefix."_nsnst_protected_ranges` (`ip_lo` int(10) unsigned NOT NULL default '0', `ip_hi` int(10) unsigned NOT NULL default '0', `date` varchar(20) NOT NULL default '0', `notes` text NOT NULL, `c2c` char(2) NOT NULL default '00', KEY `code` (`ip_lo`, `ip_hi`, `c2c`))");
if(!$result) { echo "- Create ".$prefix."_nsnst_protected_ranges failed<br />\n"; $message = ""; }
// CREATE TABLE nsnst_tracked_ips
$result = $db->sql_query("CREATE TABLE `".$prefix."_nsnst_tracked_ips` (`tid` int(10) NOT NULL auto_increment, `ip_addr` varchar(15) NOT NULL default '', `hostname` varchar(100) NOT NULL default '', `user_id` int(11) NOT NULL default '1', `username` varchar(60) NOT NULL default '', `user_agent` text NOT NULL, `date` varchar(20) NOT NULL default '0', `page` text NOT NULL, `x_forward_for` varchar(32) NOT NULL default '', `client_ip` varchar(32) NOT NULL default '', `remote_addr` varchar(32) NOT NULL default '', `remote_port` varchar(11) NOT NULL default '', `request_method` varchar(10) NOT NULL default '', `c2c` CHAR(2) DEFAULT '00' NOT NULL, PRIMARY KEY (`tid`), KEY `tid` (`tid`), KEY `maintracking` (`ip_addr`, `hostname`))");
if(!$result) { echo "- Create ".$prefix."_nsnst_tracked_ips failed<br />\n"; $message = ""; }
// INSERT INTO TABLE nsnst_config
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('crypt_salt', 'N$')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('lookup_link', 'http://DNSstuff.com/tools/whois.ch?ip=')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('search_block_perpage', '50')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('search_block_sort_column', 'date')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('search_block_sort_direction', 'desc')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('search_track_perpage', '50')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('search_track_sort_column', '6')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('search_track_sort_direction', 'desc')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('search_user_perpage', '50')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('search_user_sort_column', 'username')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('search_user_sort_direction', 'asc')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('staccess_path', '')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('track_active', '0')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('track_del', '100')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('track_max', '1000')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('track_perpage', '50')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('track_sort_column', 'date')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('track_sort_direction', 'desc')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
// UPDATE TABLE nsnst_config
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_name`='block_perpage' WHERE `config_name`='perpage'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_name`='block_sort_column' WHERE `config_name`='sort_column'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_name`='block_sort_direction' WHERE `config_name`='sort_direction'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='2.1.0' WHERE `config_name`='version_number'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value` = '0' WHERE `config_name` = 'http_auth'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_config` ORDER BY `config_name`");
if(!$result) { echo "- Adjust Order ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
// OPTIMIZE TABLES
$result = $db->sql_query("OPTIMIZE TABLE `".$prefix."_nsnst_config`");
if(!$result) { echo "- Optimize Table ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
// UPDATE TABLE nsnst_admins
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_admins` CHANGE `passwd` `password_md5` VARCHAR(60) NOT NULL");
if(!$result) { echo "- Update ".$prefix."_nsnst_admins failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_admins` ADD `password` VARCHAR(20) NOT NULL AFTER `login`");
if(!$result) { echo "- Update ".$prefix."_nsnst_admins failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_admins` ADD `password_crypt` VARCHAR(60) NOT NULL AFTER `password_md5`");
if(!$result) { echo "- Update ".$prefix."_nsnst_admins failed<br />\n"; $message = ""; }
// UPDATE TABLE nsnst_blockers
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_blockers` VALUES (10, 'admin', 0, 0, 0, '', 'Abuse-Admin', 'abuse_admin.tpl', 0, 0, '')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_blockers failed<br />\n"; $message = ""; }
// CREATE TABLE nsnst_countries
$result = $db->sql_query("CREATE TABLE `".$prefix."_nsnst_countries` (`c2c` char(2) NOT NULL default '', `country` varchar(60) NOT NULL default '', KEY (`c2c`))");
if(!$result) { echo "- Create ".$prefix."_nsnst_countries failed<br />\n"; $message = ""; }
// INSERT INTO TABLE nsnst_countries
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_countries` VALUES ('00', 'Unknown')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_countries failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_countries` VALUES ('01', 'IANA Reserved')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_countries failed<br />\n"; $message = ""; }
// CREATE TABLE nsnst_reserved_ranges
$result = $db->sql_query("CREATE TABLE `".$prefix."_nsnst_reserved_ranges` (`ip_lo` int(10) unsigned NOT NULL default '0', `ip_hi` int(10) unsigned NOT NULL default '0', `date` varchar(20) NOT NULL default '0', `c2c` char(2) NOT NULL default '00', KEY `code` (`ip_lo`, `ip_hi`, `c2c`))");
if(!$result) { echo "- Create ".$prefix."_nsnst_reserved_ranges failed<br />\n"; $message = ""; }
// INSERT INTO TABLE nsnst_reserved_ranges
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_reserved_ranges` VALUES (0, 16777215, '', '01')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_reserved_ranges failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_reserved_ranges` VALUES (16777216, 33554431, '', '01')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_reserved_ranges failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_reserved_ranges` VALUES (33554432, 50331647, '', '01')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_reserved_ranges failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_reserved_ranges` VALUES (167772160, 184549375, '', '01')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_reserved_ranges failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_reserved_ranges` VALUES (2130706432, 2147483647, '', '01')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_reserved_ranges failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_reserved_ranges` VALUES (2851995648, 2852061183, '', '01')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_reserved_ranges failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_reserved_ranges` VALUES (2886729728, 2887778303, '', '01')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_reserved_ranges failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_reserved_ranges` VALUES (3187671040, 3204448255, '', '01')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_reserved_ranges failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_reserved_ranges` VALUES (3221225472, 3221258239, '', '01')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_reserved_ranges failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_reserved_ranges` VALUES (3232235520, 3232301055, '', '01')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_reserved_ranges failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_reserved_ranges` VALUES (4294967040, 4294967295, '', '01')");
if(!$result) { echo "- Insert into ".$prefix."_nsnst_reserved_ranges failed<br />\n"; $message = ""; }
echo "$message<hr />\n";
echo "Operation Complete!<br />\n";
echo "Click the link below to reset the blockers:<br />\n";
echo "Goto <a href=\"".$admin_file.".php?op=ABMain\">$pagename Admin</a>\n";
CloseTable();
include("footer.php");

?>