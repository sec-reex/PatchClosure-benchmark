<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

@set_time_limit(600);
$pagetitle = $pagename.": Upgrade 2.5.02 to 2.5.03";
include("header.php");
title("$pagetitle");
OpenTable();
echo "Operation Status!<br />\n";
echo "<hr />\n";
$message = "Everything seems to have completed successfully :)<br />\n";
// ALTER nsnst_tracked_ips
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` ADD `refered_from` TEXT NOT NULL AFTER `user_agent`");
if(!$result) { echo "- Alter ".$prefix."_nsnst_tracked_ips failed<br />\n"; $message = ""; }
$db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` DROP INDEX `ip_addr`");
$db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` DROP INDEX `ip_long`");
$db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` DROP INDEX `user_id`");
$db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` DROP INDEX `username`");
$db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` DROP INDEX `user_agent`");
$db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` DROP INDEX `refered_from`");
$db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` DROP INDEX `date`");
$db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` DROP INDEX `page`");
$db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` DROP INDEX `c2c`");
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` ADD INDEX `ip_addr` (`ip_addr`)");
if(!$result) { echo "- Alter ".$prefix."_nsnst_tracked_ips failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` ADD INDEX `ip_long` (`ip_long`)");
if(!$result) { echo "- Alter ".$prefix."_nsnst_tracked_ips failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` ADD INDEX `user_id` (`user_id`)");
if(!$result) { echo "- Alter ".$prefix."_nsnst_tracked_ips failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` ADD INDEX `username` (`username`)");
if(!$result) { echo "- Alter ".$prefix."_nsnst_tracked_ips failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` ADD INDEX `user_agent` (`user_agent`(255))");
if(!$result) { echo "- Alter ".$prefix."_nsnst_tracked_ips failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` ADD INDEX `refered_from` (`refered_from`(255))");
if(!$result) { echo "- Alter ".$prefix."_nsnst_tracked_ips failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` ADD INDEX `date` (`date`)");
if(!$result) { echo "- Alter ".$prefix."_nsnst_tracked_ips failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` ADD INDEX `page` (`page`(255))");
if(!$result) { echo "- Alter ".$prefix."_nsnst_tracked_ips failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_tracked_ips` ADD INDEX `c2c` (`c2c`)");
if(!$result) { echo "- Alter ".$prefix."_nsnst_tracked_ips failed<br />\n"; $message = ""; }
$db->sql_query("UPDATE `".$prefix."_nsnst_tracked_ips` SET `refered_from`='Before NukeSentinel(tm)'");
$db->sql_query("OPTIMIZE TABLE `".$prefix."_nsnst_tracked_ips`");
// UPDATE nsnst_config
$tms = time();
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='$tms' WHERE `config_name`='version_check'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='2.5.03' WHERE `config_name`='version_newest'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='2.5.03' WHERE `config_name`='version_number'");
if(!$result) { echo "- Update ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$db->sql_query("ALTER TABLE `".$prefix."_nsnst_config` ORDER BY `config_name`");
$db->sql_query("OPTIMIZE TABLE `".$prefix."_nsnst_config`");
echo "$message<hr />\n";
echo "Operation Complete!<br />\n";
echo "Click the link below to goto admin:<br />\n";
echo "Goto <a href=\"".$admin_file.".php?op=ABMain\">$pagename Admin</a>\n";
CloseTable();
include("footer.php");

?>