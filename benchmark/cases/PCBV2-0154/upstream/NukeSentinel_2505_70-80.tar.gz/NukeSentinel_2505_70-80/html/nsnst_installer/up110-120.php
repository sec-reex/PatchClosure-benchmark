<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

$pagetitle = $pagename.": Upgrade 1.1.0 to 1.2.0";
include("header.php");
title("$pagetitle");
OpenTable();
echo "Operation Status!<br />\n";
echo "<hr />\n";
$message = "Everything seems to have completed successfully :)<br />\n";
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('admin_contact', '$adminmail')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('dis_link', '0')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("INSERT INTO `".$prefix."_nsnst_config` VALUES ('dis_reason', '0')");
if(!$result) { echo "- Add field ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='0' WHERE `config_name`='act_authors'");
if(!$result) { echo "- Reset Blocker ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='0' WHERE `config_name`='act_clike'");
if(!$result) { echo "- Reset Blocker ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='0' WHERE `config_name`='act_filters'");
if(!$result) { echo "- Reset Blocker ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='0' WHERE `config_name`='act_harvest'");
if(!$result) { echo "- Reset Blocker ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='0' WHERE `config_name`='act_script'");
if(!$result) { echo "- Reset Blocker ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("UPDATE `".$prefix."_nsnst_config` SET `config_value`='0' WHERE `config_name`='act_union'");
if(!$result) { echo "- Reset Blocker ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='pc_killer'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DELETE FROM `".$prefix."_nsnst_config` WHERE `config_name`='pc_killer_loop'");
if(!$result) { echo "- Remove Value ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("ALTER TABLE `".$prefix."_nsnst_config` ORDER BY `config_name`");
if(!$result) { echo "- Adjust Order ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
echo "$message<hr />\n";
echo "Operation Complete!<br />\n";
echo "With this upgrade all blockers have been turned off due to new values being added. Click the link below to reset the blockers:<br />\n";
echo "Goto <a href=\"".$admin_file.".php?op=ABConfig\">$pagename Config</a>\n";
CloseTable();
include("footer.php");

?>