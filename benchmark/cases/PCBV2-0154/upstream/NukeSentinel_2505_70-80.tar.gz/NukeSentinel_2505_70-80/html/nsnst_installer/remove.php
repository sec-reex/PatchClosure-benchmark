<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

$pagetitle = $pagename.": Removal";
include("header.php");
title("$pagetitle");
OpenTable();
echo "Operation Status!<br />\n";
echo "<hr />\n";
$message = "Everything seems to have completed successfully :)<br />\n";
$result = $db->sql_query("DROP TABLE `".$prefix."_nsnst_admins`");
if(!$result) { echo "- Remove ".$prefix."_nsnst_admins failed<br />\n"; $message = ""; }
$result = $db->sql_query("DROP TABLE `".$prefix."_nsnst_blocked_ips`");
if(!$result) { echo "- Remove ".$prefix."_nsnst_blocked_ips failed<br />\n"; $message = ""; }
$result = $db->sql_query("DROP TABLE `".$prefix."_nsnst_blocked_ranges`");
if(!$result) { echo "- Remove ".$prefix."_nsnst_blocked_ranges failed<br />\n"; $message = ""; }
$result = $db->sql_query("DROP TABLE `".$prefix."_nsnst_blockers`");
if(!$result) { echo "- Remove ".$prefix."_nsnst_blockers failed<br />\n"; $message = ""; }
$result = $db->sql_query("DROP TABLE `".$prefix."_nsnst_cidrs`");
if(!$result) { echo "- Remove ".$prefix."_nsnst_cidrs failed<br />\n"; $message = ""; }
$result = $db->sql_query("DROP TABLE `".$prefix."_nsnst_config`");
if(!$result) { echo "- Remove ".$prefix."_nsnst_config failed<br />\n"; $message = ""; }
$result = $db->sql_query("DROP TABLE `".$prefix."_nsnst_countries`");
if(!$result) { echo "- Remove ".$prefix."_nsnst_countries failed<br />\n"; $message = ""; }
if($db->sql_numrows($db->sql_query("SHOW TABLES LIKE '".$prefix."_nsnst_flood'")) > 0) {
  $result = $db->sql_query("DROP TABLE `".$prefix."_nsnst_flood`");
  if(!$result) { echo "- Remove ".$prefix."_nsnst_flood failed<br />\n"; $message = ""; }
}
$result = $db->sql_query("DROP TABLE `".$prefix."_nsnst_excluded_ranges`");
if(!$result) { echo "- Remove ".$prefix."_nsnst_excluded_ranges failed<br />\n"; $message = ""; }
$result = $db->sql_query("DROP TABLE `".$prefix."_nsnst_ip2country`");
if(!$result) { echo "- Remove ".$prefix."_nsnst_ip2country failed<br />\n"; $message = ""; }
$result = $db->sql_query("DROP TABLE `".$prefix."_nsnst_protected_ranges`");
if(!$result) { echo "- Remove ".$prefix."_nsnst_protected_ranges failed<br />\n"; $message = ""; }
$result = $db->sql_query("DROP TABLE `".$prefix."_nsnst_tracked_ips`");
if(!$result) { echo "- Remove ".$prefix."_nsnst_tracked_ips failed<br />\n"; $message = ""; }
echo "$message<hr />\n";
echo "Operation Complete!<br />\n";
echo "Goto <a href=\"".$admin_file.".php\">Site Admin</a>\n";
CloseTable();
include("footer.php");

?>