<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

$pagetitle = _AB_NUKESENTINEL.": "._AB_EDITIP;
include("header.php");
OpenTable();
OpenMenu(_AB_EDITIP);
ipbanmenu();
CarryMenu();
blockedipmenu();
CloseMenu();
CloseTable();
echo "<br />\n";
OpenTable();
$getIPs = $db->sql_fetchrow($db->sql_query("SELECT * FROM `".$prefix."_nsnst_blocked_ips` WHERE `ip_addr`='$xIPs'"));
$getIPs['date'] = date("Y-m-d H:i:s",$getIPs['date']);
$getIPs['expires'] = round(($getIPs['expires'] - time()) / 86400);
echo "<table align='center' border='0' cellpadding='2' cellspacing='2'>\n";
echo "<form action='".$admin_file.".php' method='post'>\n";
echo "<tr><td align='center' colspan='2'>"._AB_EDITIPS."</td></tr>\n";
$tip = explode(".", $xIPs);
echo "<tr><td bgcolor='$bgcolor2'><b>"._AB_IPBLOCKED.":</b></td>\n";
echo "<td><input type='text' name='xip[0]' value='$tip[0]' size='4' maxlength='3' align='right' />\n";
echo ". <input type='text' name='xip[1]' value='$tip[1]' size='4' maxlength='3' align='right' />\n";
echo ". <input type='text' name='xip[2]' value='$tip[2]' size='4' maxlength='3' align='right' />\n";
echo ". <input type='text' name='xip[3]' value='$tip[3]' size='4' maxlength='3' align='right' /></td></tr>\n";
echo "<tr><td bgcolor='$bgcolor2'><b>"._AB_USERID.":</b></td><td><input type='text' name='xuser_id' size='10' value='".$getIPs['user_id']."' /></td></tr>\n";
echo "<tr><td bgcolor='$bgcolor2'><b>"._AB_USERNAME.":</b></td><td><input type='text' name='xusername' size='20' value='".$getIPs['username']."' /></td></tr>\n";
echo "<tr><td bgcolor='$bgcolor2'><b>"._AB_AGENT.":</b></td><td><input type='text' name='xuser_agent' size='40' value='".$getIPs['user_agent']."' /></td></tr>\n";
echo "<tr><td bgcolor='$bgcolor2'><b>"._AB_BLOCKEDON.":</b></td><td><input type='text' name='xdatetime' size='30' value='".$getIPs['date']."' /></td></tr>\n";
echo "<tr><td bgcolor='$bgcolor2' valign='top'><b>"._AB_EXPIRESIN.":</b></td><td><select name='xexpires'>\n";
echo "<option value='0'";
if($getIPs['expires']==0) { echo " selected"; }
echo ">"._AB_PERMENANT."</option>\n";
$i=1;
while($i<=365) {
  echo "<option value='$i'";
  if($getIPs['expires']==$i) { echo " selected"; }
  $expiredate = date("Y-m-d", time() + ($i * 86400));
  echo ">$i ($expiredate)</option>\n";
  $i++;
}
echo "</select><br />\n"._AB_EXPIRESINS."</td></tr>\n";
echo "<tr><td bgcolor='$bgcolor2'><b>"._AB_COUNTRY.":</b></td>\n";
echo "<td><select name='xc2c'>\n";
echo "<option value='00'>"._AB_SELECTCOUNTRY."</option>\n";
$result = $db->sql_query("SELECT * FROM `".$prefix."_nsnst_countries` ORDER BY `country`");
while($countryrow = $db->sql_fetchrow($result)) {
  echo "<option value='".$countryrow['c2c']."'";
  if($countryrow['c2c'] == $getIPs['c2c']) { echo " selected"; }
  echo ">".$countryrow['country']." (".$countryrow['c2c'].")</option>\n";
}
echo "</select></td></tr>\n";
echo "<tr><td bgcolor='$bgcolor2' valign='top'><b>"._AB_NOTES.":</b></td><td><textarea name='xnotes' $textrowcol>".$getIPs['notes']."</textarea></td></tr>\n";
echo "<tr><td bgcolor='$bgcolor2'><b>"._AB_REASON.":</b></td><td><select name='xreason'>";
$result = $db->sql_query("SELECT * FROM `".$prefix."_nsnst_blockers` ORDER BY `block_name`");
while($blockerrow = $db->sql_fetchrow($result)) {
  echo "<option value='".$blockerrow['blocker']."'";
  if($getIPs['reason']==$blockerrow['blocker']) { echo " selected"; }
  echo ">".$blockerrow['reason']."</option>\n";
}
echo "</select></td></tr>\n";
echo "<tr><td bgcolor='$bgcolor2' colspan='2'>&nbsp;</td></tr>\n";
$getIPs['query_string'] = htmlentities(base64_decode($getIPs['query_string']));
$getIPs['query_string'] = str_replace("%20", " ", $getIPs['query_string']);
$getIPs['query_string'] = str_replace("/**/", "/* */", $getIPs['query_string']);
echo "<tr><td bgcolor='$bgcolor2'><b>"._AB_QUERY.":</b></td><td>".info_img("<b>"._AB_QUERY.":</b> ".$getIPs['query_string'], r)."</td></tr>\n";
echo "<tr><td bgcolor='$bgcolor2'><b>"._AB_X_FORWARDED.":</b></td><td>".$getIPs['x_forward_for']."</td></tr>\n";
echo "<tr><td bgcolor='$bgcolor2'><b>"._AB_CLIENT_IP.":</b></td><td>".$getIPs['client_ip']."</td></tr>\n";
echo "<tr><td bgcolor='$bgcolor2'><b>"._AB_REMOTE_ADDR.":</b></td><td>".$getIPs['remote_addr']."</td></tr>\n";
echo "<tr><td bgcolor='$bgcolor2'><b>"._AB_REMOTE_PORT.":</b></td><td>".$getIPs['remote_port']."</td></tr>\n";
echo "<tr><td bgcolor='$bgcolor2'><b>"._AB_REQUEST_METHOD.":</b></td><td>".$getIPs['request_method']."</td></tr>\n";
echo "<input type='hidden' name='op' value='ABBlockedIPEditSave' />\n";
echo "<input type='hidden' name='xop' value='$xop' />\n";
echo "<input type='hidden' name='sip' value='$sip' />\n";
echo "<input type='hidden' name='old_xIPs' value='$xIPs' />\n";
echo "<input type='hidden' name='min' value='$min' />\n";
echo "<input type='hidden' name='column' value='$column' />\n";
echo "<input type='hidden' name='direction' value='$direction' />\n";
echo "<tr><td align='center' colspan='2'><input type=submit value='"._AB_SAVECHANGES."' /></td></tr>\n";
echo "</form></table>\n";
CloseTable();
include("footer.php");

?>