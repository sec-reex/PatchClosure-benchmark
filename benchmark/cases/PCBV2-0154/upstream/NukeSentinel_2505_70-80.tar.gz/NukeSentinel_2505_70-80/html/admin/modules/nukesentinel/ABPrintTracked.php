<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

echo "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n";
echo "<html><head>\n";
$pagetitle = _AB_NUKESENTINEL.": "._AB_PRINTTRACKEDIPS;
echo "<title>$pagetitle</title>\n";
$theme_Sel = get_theme();
include_once("themes/$theme_Sel/theme.php");
echo "<LINK REL='StyleSheet' HREF='themes/$theme_Sel/style/style.css' TYPE='text/css' MEDIA='screen'>\n";
echo "</head><body>\n";
echo "<h1 align='center'>$pagetitle</h1>\n";
$totalselected = $db->sql_numrows($db->sql_query("SELECT `username`, `ip_addr`, `ip_long`, MAX(`date`), COUNT(*) FROM `".$prefix."_nsnst_tracked_ips` GROUP BY 1,2,3"));
if($totalselected > 0) {
  echo "<table align='center' cellpadding='2' cellspacing='2' border='2'>\n";
  echo "<tr>\n";
  echo "<td><b>"._AB_USER."</b></td>\n";
  echo "<td><b>"._AB_IPADDRESS."</b></td>\n";
  echo "<td align='center'><b>"._AB_COUNTRY."</b></td>\n";
  echo "<td align='center'><b>"._AB_HOSTNAME."</b></td>\n";
  echo "<td align='center'><b>"._AB_LASTVIEWED."</b></td>\n";
  echo "<td align='center'><b>"._AB_HITS."</b></td>\n";
  $result = $db->sql_query("SELECT `user_id`, `username`, `ip_addr`, `ip_long`, MAX(`date`), COUNT(*), MIN(`tid`), `c2c` FROM `".$prefix."_nsnst_tracked_ips` $modfilter GROUP BY 2,3,4 ORDER BY `ip_addr`");
  while(list($userid,$username,$ipaddr,$ip_long,$lastview,$hits,$tid,$c2c) = $db->sql_fetchrow($result)){
    echo "<tr>";
    if($userid != 1) { echo "<td>$username</td>"; } else { echo "<td>&nbsp;</td>"; }
    echo "<td>$ipaddr</td>";
    $countrytitleinfo = abget_countrytitle($c2c);
    echo "<td align='center'>".$countrytitleinfo['country']."</td>";
    echo "<td align='center'>$ip_long</td>";
    echo "<td align='center'>".date("Y-m-d \@ H:i:s",$lastview)."</td>";
    echo "<td align='center'>$hits</td>";
    echo "</tr>";
  }
  // End IP Stats
  echo "</table>";
} else {
  echo "<center><b>"._AB_NOIPS."</b></center>\n";
}
echo "</body></html>\n";

?>