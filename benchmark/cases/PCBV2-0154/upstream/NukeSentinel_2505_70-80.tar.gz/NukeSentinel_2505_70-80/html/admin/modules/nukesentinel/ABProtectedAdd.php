<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

$pagetitle = _AB_NUKESENTINEL.": "._AB_ADDPROTECTED;
include("header.php");
OpenTable();
OpenMenu(_AB_ADDPROTECTED);
ipbanmenu();
CarryMenu();
protectedmenu();
CloseMenu();
CloseTable();
echo "<br />\n";
OpenTable();
echo "<form action='".$admin_file.".php' method='post'>\n";
echo "<table align='center' border='0' cellpadding='2' cellspacing='2'>\n";
echo "<tr bgcolor='$bgcolor1'><td align='center' class='content' colspan='2'>"._AB_ADDPROTECTEDS."</td></tr>\n";
echo "<tr><td bgcolor='$bgcolor2'><b>"._AB_IPLO.":</b></td>\n";
echo "<td><input type='text' name='xip_lo[0]' size='4' maxlength='3' align='right' />\n";
echo ". <input type='text' name='xip_lo[1]' size='4' value='0' maxlength='3' align='right' />\n";
echo ". <input type='text' name='xip_lo[2]' size='4' value='0' maxlength='3' align='right' />\n";
echo ". <input type='text' name='xip_lo[3]' size='4' value='0' maxlength='3' align='right' /></td></tr>\n";
echo "<tr><td bgcolor='$bgcolor2'><b>"._AB_IPHI.":</b></td>\n";
echo "<td><input type='text' name='xip_hi[0]' size='4' maxlength='3' align='right' />\n";
echo ". <input type='text' name='xip_hi[1]' size='4' value='255' maxlength='3' align='right' />\n";
echo ". <input type='text' name='xip_hi[2]' size='4' value='255' maxlength='3' align='right' />\n";
echo ". <input type='text' name='xip_hi[3]' size='4' value='255' maxlength='3' align='right' /></td></tr>\n";
echo "<tr><td bgcolor='$bgcolor2' valign='top'><b>"._AB_NOTES.":</b></td><td><textarea name='xnotes' rows='10' cols='40'>"._AB_ADDBY." $aid</textarea></td></tr>\n";
echo "<tr><td bgcolor='$bgcolor2'><b>"._AB_COUNTRY.":</b></td>\n";
echo "<td><select name='xc2c'>\n";
$result = $db->sql_query("SELECT * FROM `".$prefix."_nsnst_countries` ORDER BY `country`");
while($countryrow = $db->sql_fetchrow($result)) {
  echo "<option value='".$countryrow['c2c']."'>".$countryrow['country']." (".$countryrow['c2c'].")</option>\n";
}
echo "</select></td></tr>\n";
echo "<tr><td colspan='2' align='center'><input type='checkbox' name='another' value='1' checked='checked' />"._AB_ADDANOTHERRANGE."</td></tr>\n";
echo "<tr><td colspan='2' align='center'><input type='hidden' name='op' value='ABProtectedAddSave' /><input type='submit' value='"._AB_ADDPROTECTED."' /></td></tr>\n";
echo "</table></form>\n";
CloseTable();
include("footer.php");

?>