<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

$pagetitle = _AB_NUKESENTINEL.": "._AB_EXCLUDEDRANGEMENU;
include("header.php");
$ip_sets = abget_configs();
OpenTable();
OpenMenu(_AB_EXCLUDEDRANGEMENU);
ipbanmenu();
CarryMenu();
excludedmenu();
CloseMenu();
CloseTable();
include("footer.php");

?>