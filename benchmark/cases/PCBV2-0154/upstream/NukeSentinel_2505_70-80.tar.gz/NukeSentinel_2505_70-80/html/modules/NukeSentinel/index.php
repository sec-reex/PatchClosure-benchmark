<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

if(!defined('MODULE_FILE')) { die('You can\'t access this file directly...'); }
$module_name = basename(dirname(__FILE__));
require_once('mainfile.php');
$index = 1;
define('INDEX_FILE', TRUE);
$ab_config = abget_configs();
$checkrow = $db->sql_numrows($db->sql_query('SELECT * FROM `'.$prefix.'_nsnst_ip2country`'));
if($checkrow > 0) { $tableexist = 1; } else { $tableexist = 0; }
if (!isset($op)) $op='';
if($op == 'STIP2C' AND $tableexist != 1) { $op = 'STIndex'; }
if(!$op) { $op = 'STIndex'; }
include_once('modules/'.$module_name.'/public/functions.php');
switch($op) {

  case 'STIndex':include('modules/'.$module_name.'/public/STIndex.php');break;
  case 'STIPS':include('modules/'.$module_name.'/public/STIPS.php');break;
  case 'STRanges':include('modules/'.$module_name.'/public/STRanges.php');break;
  case 'STReferers':include('modules/'.$module_name.'/public/STReferers.php');break;
  case 'STIP2C':include('modules/'.$module_name.'/public/STIP2C.php');break;

}

?>