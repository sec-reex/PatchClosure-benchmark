<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

if(!defined('NUKE_FILE') && !defined('BLOCK_FILE')) { die('You can\'t access this file directly...'); }
global $db, $prefix, $ab_config;
$total_ips = $db->sql_numrows($db->sql_query('SELECT * FROM `'.$prefix.'_nsnst_blocked_ips`'));
if(!$total_ips) { $total_ips = 0; }
$content  = '<center><img src="images/nukesentinel/Sentinel_Medium.png" alt="You have been warned!" title="You have been warned!" /><br />We have caught '.intval($total_ips).' shameful hackers.</center>';
$content .= '<hr /><center><a href="http://www.nukescripts.net" target="_blank" title="NukeSentinel&trade; Available at Nuke Scripts Network">'._AB_NUKESENTINEL.' '.$ab_config['version_number'].'</a></center>'."\n";

?>
