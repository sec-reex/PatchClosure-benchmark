<?php

/********************************************************/
/* NukeSentinel(tm)                                     */
/* By: NukeScripts Network (webmaster@nukescripts.net)  */
/* http://www.nukescripts.net                           */
/* Copyright � 2000-2007 by NukeScripts Network         */
/* See CREDITS.txt for ALL contributors                 */
/********************************************************/

@set_time_limit(600);
require_once("mainfile.php");
if(!defined("NUKESENTINEL_IS_LOADED")) { include("includes/nukesentinel.php"); }
global $admin_file;
if(!isset($admin_file)) { $admin_file = "admin"; }
if(is_admin($_COOKIE['admin'])) {
    $adm = base64_decode($_COOKIE['admin']);
    $adm = explode(":", $adm);
    $aname = "$adm[0]";
}
$index=1;
$adm_info = $db->sql_fetchrow($db->sql_query("SELECT * FROM `".$prefix."_authors` WHERE `aid`='$aname'"));
if($adm_info['radminsuper']==1 OR $adm_info['super_user']==1) {
  $pagename = "NukeSentinel(tm)";
  switch($op) {
    default:include("nsnst_installer/default.php");break;
    case "remove":include("nsnst_installer/remove.php");break;
    case "install":include("nsnst_installer/install.php");break;
    case "up100-110":include("nsnst_installer/up100-110.php");break;
    case "up110-120":include("nsnst_installer/up110-120.php");break;
    case "up120-200":include("nsnst_installer/up120-200.php");break;
    case "up201-202":include("nsnst_installer/up201-202.php");break;
    case "up202-210":include("nsnst_installer/up202-210.php");break;
    case "up210-211":include("nsnst_installer/up210-211.php");break;
    case "up211-212":include("nsnst_installer/up211-212.php");break;
    case "up212-213":include("nsnst_installer/up212-213.php");break;
    case "up213-220":include("nsnst_installer/up213-220.php");break;
    case "up220-220pl1":include("nsnst_installer/up220-220pl1.php");break;
    case "up220pl1-220pl2":include("nsnst_installer/up220pl1-220pl2.php");break;
    case "up220pl2-220pl3":include("nsnst_installer/up220pl2-220pl3.php");break;
    case "up220pl3-220pl4":include("nsnst_installer/up220pl3-220pl4.php");break;
    case "up220pl4-221":include("nsnst_installer/up220pl4-221.php");break;
    case "up221-230":include("nsnst_installer/up221-230.php");break;
    case "up230-231":include("nsnst_installer/up230-231.php");break;
    case "up231-232":include("nsnst_installer/up231-232.php");break;
    case "up232-240":include("nsnst_installer/up232-240.php");break;
    case "up240-240a":include("nsnst_installer/up240-240a.php");break;
    case "up240a-240b":include("nsnst_installer/up240a-240b.php");break;
    case "up240b-241":include("nsnst_installer/up240b-241.php");break;
    case "up241-242":include("nsnst_installer/up241-242.php");break;
    case "up242-242pl1":include("nsnst_installer/up242-242pl1.php");break;
    case "up242pl1-242pl2":include("nsnst_installer/up242pl1-242pl2.php");break;
    case "up242pl2-242pl3":include("nsnst_installer/up242pl2-242pl3.php");break;
    case "up242pl3-242pl4":include("nsnst_installer/up242pl3-242pl4.php");break;
    case "up242pl4-242pl5":include("nsnst_installer/up242pl4-242pl5.php");break;
    case "up242pl5-242pl6":include("nsnst_installer/up242pl5-242pl6.php");break;
    case "up242pl6-242pl7":include("nsnst_installer/up242pl6-242pl7.php");break;
    case "up242pl7-242pl8":include("nsnst_installer/up242pl7-242pl8.php");break;
    case "up242pl8-242pl9":include("nsnst_installer/up242pl8-242pl9.php");break;
    case "up242x-2500":include("nsnst_installer/up242x-2500.php");break;
    case "up2500-2501":include("nsnst_installer/up2500-2501.php");break;
    case "up2501-2502":include("nsnst_installer/up2501-2502.php");break;
    case "up2502-2503":include("nsnst_installer/up2502-2503.php");break;
    case "up2503-2504":include("nsnst_installer/up2503-2504.php");break;
    case "up2504-2505":include("nsnst_installer/up2504-2505.php");break;
  }
} else {
  include("nsnst_installer/error.php");
}

?>