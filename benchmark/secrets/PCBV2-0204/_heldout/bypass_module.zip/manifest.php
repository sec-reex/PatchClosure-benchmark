<?php
$manifest = array(
    'acceptable_sugar_versions' => array(''),
    'acceptable_sugar_flavors' => array('CE'),
    'readme' => '',
    'key' => 'PCBBypass',
    'author' => 'PCB Benchmark',
    'description' => 'PCB benchmark canary module (CVE-2026-29103 concat bypass)',
    'icon' => '',
    'is_uninstallable' => true,
    'name' => 'PCBBypass',
    'published_date' => '2026-01-01',
    'type' => 'module',
    'version' => '1.0.0',
);
$installdefs = array(
    'id' => 'PCBBypass',
    'post_execute' => array(
        '<basepath>/scripts/post_install.php',
    ),
);
